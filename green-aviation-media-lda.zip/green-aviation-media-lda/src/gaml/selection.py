"""Model-selection diagnostics: C_v coherence (Gensim) and held-out perplexity (sklearn)."""
from __future__ import annotations

import numpy as np
from gensim.corpora import Dictionary
from gensim.models.coherencemodel import CoherenceModel
from sklearn.model_selection import train_test_split

from .model import fit_lda, top_words, topic_word


class CoherenceScorer:
    """C_v coherence of top-N topic words against the preprocessed documents.

    Reference texts = the full token lists of the analytic corpus (after
    preprocessing, before min_df/max_df pruning); this choice is fixed here
    because it was not archived for the original diagnostics.
    """

    def __init__(self, token_lists, topn: int = 10):
        self.texts = [list(t) for t in token_lists]
        self.dictionary = Dictionary(self.texts)
        self.topn = topn

    def score(self, topics: list[list[str]]) -> tuple[float, np.ndarray]:
        cm = CoherenceModel(
            topics=topics, texts=self.texts, dictionary=self.dictionary,
            coherence="c_v", topn=self.topn, processes=1,
        )
        per_topic = np.asarray(cm.get_coherence_per_topic(), dtype=float)
        return float(np.mean(per_topic)), per_topic


def heldout_split(n_docs: int, fraction: float, seed: int):
    idx = np.arange(n_docs)
    return train_test_split(idx, test_size=fraction, random_state=seed, shuffle=True)


def evaluate_k(X, vocab, scorer: CoherenceScorer, cfg: dict, k: int, seed: int,
               train_idx, test_idx) -> dict:
    """Fit on all docs (coherence, topic-word for stability) and on train docs (perplexity)."""
    lda_full = fit_lda(X, cfg, n_components=k, seed=seed)
    beta = topic_word(lda_full)
    cv, cv_topics = scorer.score(top_words(beta, vocab, scorer.topn))

    lda_train = fit_lda(X[train_idx], cfg, n_components=k, seed=seed)
    perp = float(lda_train.perplexity(X[test_idx]))
    return {"k": k, "seed": seed, "cv": cv, "cv_per_topic": cv_topics,
            "heldout_perplexity": perp, "beta": beta}
