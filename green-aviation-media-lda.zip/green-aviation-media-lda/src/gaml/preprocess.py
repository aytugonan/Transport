"""Text preprocessing (manuscript Section 3.2, Supplementary Table S2).

Pipeline, in order:
  1. HTML entity decoding/removal, URL and e-mail removal
  2. boilerplate / web-artifact phrase removal (BOILERPLATE_PATTERNS)
  3. lowercasing
  4. tokenisation on [a-z0-9]+ (punctuation removed, hyphenated forms split:
     "net-zero" -> "net", "zero")
  5. digit removal inside tokens, except protected tokens (e.g. "co2")
  6. stopword removal (NLTK English + config/domain_stopwords.txt)
  7. WordNet lemmatisation (NLTK default = noun POS)
  8. stopword removal again (catches lemmatised forms), length filter (< 3 chars
     removed except protected tokens such as "saf", "eu", "uk", "co2")
  9. document filters: < min_valid_tokens tokens, exact duplicates

Every exclusion is logged with its reason (outputs/preprocessing/exclusions.csv),
which the original workflow did not record (manuscript Section 3.2).
"""
from __future__ import annotations

import html
import re
from pathlib import Path

import pandas as pd

URL_RE = re.compile(r"(https?://\S+|www\.\S+)", re.I)
EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
HTML_TAG_RE = re.compile(r"<[^>]+>")
HTML_ENTITY_RE = re.compile(r"&[#\w]+;")
TOKEN_RE = re.compile(r"[a-z0-9]+")
DIGIT_RE = re.compile(r"\d+")

# Repeated web-page boilerplate (Table S2, "Boilerplate and web-artifact removal").
BOILERPLATE_PATTERNS = [
    r"we use cookies[^.]*\.",
    r"accept (all )?cookies",
    r"cookie (policy|settings|notice)",
    r"subscribe (now|today|to [^.]*newsletter)[^.]*\.?",
    r"sign up (for|to) (our|the) newsletter[^.]*\.?",
    r"read more\b",
    r"click here\b",
    r"share (this|on) (article|facebook|twitter|linkedin|x)\b",
    r"follow us on [^.]*\.?",
    r"all rights reserved\.?",
    r"copyright\s*(©|\(c\))?\s*\d{0,4}[^.]*\.?",
    r"©\s*\d{0,4}[^.]*\.?",
    r"\badvertisement\b",
    r"\bsponsored content\b",
    r"\bscroll (down|to continue)\b",
    r"\bsource:\s*\S+",
    r"\b(updated|published)\s*:?\s*\d{1,2}\s+\w+\s+\d{4}",
]
BOILERPLATE_RE = re.compile("|".join(BOILERPLATE_PATTERNS), re.I)


def _load_nltk():
    import nltk
    from nltk.corpus import stopwords
    from nltk.stem import WordNetLemmatizer

    try:
        sw = set(stopwords.words("english"))
        lem = WordNetLemmatizer()
        lem.lemmatize("tests")
    except LookupError as exc:  # pragma: no cover
        raise RuntimeError(
            "NLTK data missing. Run: python scripts/setup_nltk.py"
        ) from exc
    return sw, lem


def load_domain_stopwords(path: str | Path) -> set[str]:
    words = set()
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip().lower()
        if line and not line.startswith("#"):
            words.add(line)
    return words


class Preprocessor:
    def __init__(self, cfg: dict):
        p = cfg["preprocessing"]
        self.p = p
        self.keep = {t.lower() for t in p.get("keep_tokens", [])}
        nltk_sw, self.lemmatizer = _load_nltk()
        self.stopwords = (nltk_sw | load_domain_stopwords(cfg["paths"]["domain_stopwords"])) - self.keep
        self.min_len = int(p["min_token_length"])

    def clean(self, text: str) -> str:
        text = html.unescape(str(text))
        text = HTML_TAG_RE.sub(" ", text)
        text = HTML_ENTITY_RE.sub(" ", text)
        if self.p.get("remove_urls", True):
            text = URL_RE.sub(" ", text)
        if self.p.get("remove_emails", True):
            text = EMAIL_RE.sub(" ", text)
        text = BOILERPLATE_RE.sub(" ", text)
        if self.p.get("lowercase", True):
            text = text.lower()
        return text

    def tokenize(self, text: str) -> list[str]:
        tokens = []
        for tok in TOKEN_RE.findall(self.clean(text)):
            if tok in self.keep:
                tokens.append(tok)
                continue
            if self.p.get("remove_digits", True):
                tok = DIGIT_RE.sub("", tok)
            if not tok or tok in self.stopwords:
                continue
            tok = self.lemmatizer.lemmatize(tok)
            if tok in self.stopwords:
                continue
            if len(tok) < self.min_len and tok not in self.keep:
                continue
            tokens.append(tok)
        return tokens


def preprocess_corpus(df: pd.DataFrame, cfg: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return (kept_docs_with_tokens, exclusion_log)."""
    pre = Preprocessor(cfg)
    text_col = cfg["corpus"]["text_column"]
    min_tokens = int(cfg["preprocessing"]["min_valid_tokens"])

    work = df.copy()
    work["tokens"] = [pre.tokenize(t) for t in work[text_col].fillna("")]
    work["n_tokens"] = work["tokens"].map(len)
    work["n_words_raw"] = work[text_col].fillna("").str.split().map(len)

    reasons = pd.Series("", index=work.index)
    reasons[work["n_tokens"] < min_tokens] = f"fewer_than_{min_tokens}_valid_tokens"
    if cfg["preprocessing"].get("drop_duplicates", True):
        joined = work["tokens"].map(" ".join)
        dup = joined.duplicated(keep="first") & (reasons == "")
        reasons[dup] = "duplicate_normalised_text"

    excluded = work.loc[reasons != "", ["doc_id", "source", "year"]].assign(reason=reasons[reasons != ""])
    kept = work.loc[reasons == ""].reset_index(drop=True)
    return kept, excluded.reset_index(drop=True)
