"""Internal-consistency checks of the values REPORTED in the manuscript/supplement.

These checks need no corpus: they only use the transcribed tables in
``reported/``. Status codes:
    PASS - the reported numbers agree with each other
    FLAG - an inconsistency or an impossibility that must be resolved
    NOTE - not an error, but a difference the reader should know about
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .similarity import keyword_overlap

N_EXPECTED = 408
PERIODS = ["2007–2014", "2015–2019", "2020", "2021", "2022", "2023", "2024", "2025"]
FIGURE1_REPORTED = [21, 44, 50, 129, 69, 50, 42, 3]           # Figure 1 / Table S4
FIGURE3_REPORTED = {                                            # manuscript Figure 3
    2: {3: 0, 8: 2, 10: 1, 14: 2, 20: 0},
    3: {8: 0, 10: 0, 14: 0, 20: 6},
    8: {10: 1, 14: 0, 20: 0},
    10: {14: 0, 20: 0},
    14: {20: 0},
}
ALIASES = {"USA": "United States", "UK": "United Kingdom", "The Netherlands": "Netherlands"}
PERIOD_YEARS = {"2007–2014": range(2007, 2015), "2015–2019": range(2015, 2020),
                **{str(y): [y] for y in range(2020, 2026)}}


class Report:
    def __init__(self):
        self.rows = []

    def add(self, cid, item, status, detail):
        self.rows.append({"id": cid, "item": item, "status": status, "detail": detail})

    def df(self):
        return pd.DataFrame(self.rows)


def _read(rep: Path, name: str) -> pd.DataFrame:
    return pd.read_csv(rep / name)


def run_reported_checks(reported_dir: str | Path, lemmatizer=None) -> pd.DataFrame:
    rep = Path(reported_dir)
    R = Report()
    t3 = _read(rep, "table3_period_country.csv").set_index("country_region")
    s3 = _read(rep, "tableS3_country.csv").set_index("country_region")
    s10 = _read(rep, "tableS10_annual_T3_T11.csv")
    t2 = _read(rep, "table2_corpus_construction.csv").set_index("source")
    t5 = _read(rep, "table5_model_selection.csv").set_index("k")
    s6 = _read(rep, "tableS6_multiseed.csv").set_index("k")
    s7 = _read(rep, "tableS7_topic_stability.csv")
    s8 = _read(rep, "tableS8_bootstrap.csv").set_index("k")
    t6 = _read(rep, "table6_topics.csv")

    # ---------------------------------------------------------------- corpus counts
    body = t3.drop(index="Total")
    bad_rows = body.index[body[PERIODS].sum(axis=1) != body["Total"]].tolist()
    R.add("C01", "Table 3 row sums equal row totals",
          "PASS" if not bad_rows else "FLAG", f"mismatching rows: {bad_rows or 'none'}")

    col_sums = body[PERIODS + ["Total"]].sum()
    bad_cols = [c for c in PERIODS + ["Total"] if col_sums[c] != t3.loc["Total", c]]
    R.add("C02", "Table 3 column sums equal the Total row",
          "PASS" if not bad_cols else "FLAG",
          f"mismatching columns: {bad_cols or 'none'}; column sums = {col_sums.to_dict()}")

    R.add("C03", "Table 3 grand total = 408",
          "PASS" if t3.loc["Total", "Total"] == N_EXPECTED else "FLAG", f"total = {t3.loc['Total', 'Total']}")

    fig1_ok = list(t3.loc["Total", PERIODS]) == FIGURE1_REPORTED
    R.add("C04", "Figure 1 / Table S4 period counts equal Table 3 period totals",
          "PASS" if fig1_ok else "FLAG", f"Table 3: {list(t3.loc['Total', PERIODS])}; Figure 1: {FIGURE1_REPORTED}")

    s10_period = [int(s10.loc[s10["year"].isin(PERIOD_YEARS[p]), "n_articles"].sum()) for p in PERIODS]
    R.add("C05", "Table S10 annual counts aggregate to Table 3 period totals",
          "PASS" if s10_period == FIGURE1_REPORTED else "FLAG",
          f"S10 by period: {s10_period}; sum = {int(s10['n_articles'].sum())}")

    pct = (s3["n_articles"] / s3["n_articles"].sum() * 100).round(1)
    bad_pct = s3.index[(pct - s3["pct_reported"]).abs() > 0.051].tolist()
    R.add("C06", "Table S3 sums to 408 and percentages recompute",
          "PASS" if s3["n_articles"].sum() == N_EXPECTED and not bad_pct else "FLAG",
          f"sum = {s3['n_articles'].sum()}; percentage mismatches: {bad_pct or 'none'}")

    mism = []
    for name, row in body.iterrows():
        if name == "Others*":
            continue
        key = ALIASES.get(name, name)
        if key not in s3.index or s3.loc[key, "n_articles"] != row["Total"]:
            mism.append(name)
    R.add("C07", "Table 3 category totals equal Table S3",
          "PASS" if not mism else "FLAG", f"mismatches: {mism or 'none'}")

    listed = {ALIASES.get(n, n) for n in body.index if n != "Others*"}
    others = s3.loc[[i for i in s3.index if i not in listed], "n_articles"]
    R.add("C08", "Table 3 'Others*' (26) equals the S3 categories not listed in Table 3",
          "PASS" if others.sum() == body.loc["Others*", "Total"] else "FLAG",
          f"S3 remainder = {others.sum()} over {len(others)} categories")

    n_cat = len(s3)
    n_countries = n_cat - len({"EU", "Global"} & set(s3.index))
    R.add("C09", "Number of country/region categories (Table 4: 38)",
          "NOTE" if n_cat == 38 else "FLAG",
          f"{n_cat} categories = {n_countries} countries + EU + Global. Section 3.1 says "
          f"'38 countries'; Table 4 says '38 countries-regions' (the latter is correct).")

    top4 = int(sum(s3.loc[c, "n_articles"] for c in ["United States", "United Kingdom", "Germany", "France"]))
    R.add("C10", "Top-4 categories = 288 articles = 70.6 %",
          "PASS" if top4 == 288 and round(top4 / N_EXPECTED * 100, 1) == 70.6 else "FLAG",
          f"{top4} / 408 = {top4 / N_EXPECTED:.1%}")

    icao = t2.loc["ICAO"]
    fg = t2.loc["FlightGlobal"]
    ok2 = (icao.active_retrieved + icao.recovered_verified == icao.final_articles
           and icao.initial_records - icao.active_retrieved - icao.recovered_verified == icao.excluded_verification
           and fg.after_category_filter - fg.excluded_relevance == fg.final_articles
           and t2["final_articles"].sum() == N_EXPECTED)
    R.add("C11", "Table 2 / Section 3.1 selection arithmetic",
          "PASS" if ok2 else "FLAG",
          f"ICAO 116+37={int(icao.active_retrieved + icao.recovered_verified)}; 171-116-37={int(icao.initial_records - icao.active_retrieved - icao.recovered_verified)}; "
          f"FG 250-27={int(fg.after_category_filter - fg.excluded_relevance)}; total={int(t2['final_articles'].sum())}. "
          "GreenAirNews: number of duplicates removed (230 -> 32) is not reported.")

    # ---------------------------------------------------------------- Table 6 / Figure 3
    kw = {int(t): g.sort_values("rank")["keyword"].str.lower().tolist() for t, g in t6.groupby("ms_topic")}
    sub = [2, 3, 8, 10, 14, 20]
    O = keyword_overlap({t: kw[t] for t in sub})
    bad = [(i, j, int(O.loc[i, j]), v) for i, d in FIGURE3_REPORTED.items() for j, v in d.items() if O.loc[i, j] != v]
    R.add("C12", "Figure 3 overlap counts recompute from Table 6 keyword strings",
          "PASS" if not bad else "FLAG", f"mismatches (i, j, recomputed, reported): {bad or 'none'}")

    if lemmatizer is not None:
        kw_lem = {t: sorted({lemmatizer.lemmatize(w) for w in v}) for t, v in kw.items()}
        O2 = keyword_overlap({t: kw_lem[t] for t in sub})
        changed = [(i, j, int(O.loc[i, j]), int(O2.loc[i, j])) for i in sub for j in sub
                   if i < j and O.loc[i, j] != O2.loc[i, j]]
        R.add("C13", "Figure 3 is robust to lemmatising the Table 6 keywords",
              "PASS" if not changed else "FLAG",
              f"cells that change after WordNet lemmatisation (i, j, as reported, lemmatised): {changed or 'none'}")

        unlem = sorted({(t, w) for t, v in kw.items() for w in v
                        if " " not in w and "-" not in w and lemmatizer.lemmatize(w) != w})
        R.add("C14", "Table 6 keywords are in lemmatised form (Section 3.2 says WordNet lemmatisation was applied)",
              "PASS" if not unlem else "FLAG",
              f"non-lemmatised keywords (topic, term): {unlem or 'none'}. With lemmatisation, "
              "'emissions' and 'emission' cannot both be vocabulary entries.")

    multi = sorted({(t, w) for t, v in kw.items() for w in v if " " in w or "-" in w})
    R.add("C15", "Table 6 keywords are single tokens (CountVectorizer uses unigrams; punctuation removal splits hyphens)",
          "NOTE" if multi else "PASS",
          f"multi-token display labels: {multi or 'none'}. Section 3.2 says these are display labels; "
          "the underlying unigram ranks should be reported from outputs/final_model/top_terms.csv.")

    dups = {t: [w for w in v if v.count(w) > 1] for t, v in kw.items()}
    dups = {t: sorted(set(d)) for t, d in dups.items() if d}
    R.add("C16", "No duplicated keyword within a topic", "PASS" if not dups else "FLAG", f"{dups or 'none'}")

    # ---------------------------------------------------------------- stability
    topic_mean = s7["mean_cosine"].mean()
    agg = s6.loc[20, "stability_mean"]
    R.add("C17", "Unweighted mean of Table S7 topic stabilities equals the K=20 aggregate in Table S6",
          "PASS" if abs(topic_mean - agg) < 0.005 else "FLAG",
          f"mean of 20 topic means = {topic_mean:.3f}; reported aggregate = {agg:.2f}. With equal runs per topic "
          "the two must coincide under any standard definition; the per-seed matching outputs are needed.")

    bad8 = []
    for k, row in s8.iterrows():
        d = s6.loc[k, "cv_mean"] - s6.loc[20, "cv_mean"]
        if abs(d - row["delta_cv"]) > 0.0015:
            bad8.append((k, round(d, 3), row["delta_cv"]))
    R.add("C18", "Table S8 ΔC_v equals differences of Table S6 means",
          "PASS" if not bad8 else "FLAG", f"mismatches (k, from S6, reported): {bad8 or 'none'}")

    z = {int(k): bool(r.ci_low <= 0 <= r.ci_high) for k, r in s8.iterrows()}
    R.add("C19", "Text claim: K=19 and K=21 CIs include zero",
          "PASS" if z.get(19) and z.get(21) else "FLAG", f"includes zero: {z}")

    comp = []
    for k in sorted(set(t5.index) & set(s6.index)):
        comp.append(f"K={k}: Cv {t5.loc[k, 'cv']:.3f} vs {s6.loc[k, 'cv_mean']:.3f}; "
                    f"perplexity {t5.loc[k, 'heldout_perplexity']:.1f} vs {s6.loc[k, 'perplexity_mean']:.0f}")
    R.add("C20", "Table 5 (single run) vs Table S6 (10 seeds) at common K",
          "NOTE", "; ".join(comp) + ". The manuscript treats these as different settings. If the seed-42 "
          "run belongs to the ten-seed grid under one configuration, Table 5 values would lie inside the "
          "S6 seed distribution; several do not (e.g. K=20 perplexity 1395 vs 1686 ± 31). "
          "Regenerate both from one configuration (scripts 02 and 03).")

    # ---------------------------------------------------------------- Table S10
    miss = s10[(s10["n_articles"] > 0) & (s10["T3"].isna() | s10["T11"].isna())]
    R.add("C21", "Table S10: annual topic means exist for every year with documents",
          "PASS" if miss.empty else "FLAG",
          f"years with documents but no estimate: T3 {s10.loc[(s10.n_articles > 0) & s10.T3.isna(), 'year'].tolist()}, "
          f"T11 {s10.loc[(s10.n_articles > 0) & s10.T11.isna(), 'year'].tolist()}. LDA assigns every document a "
          "proportion for every topic, so the annual mean is defined whenever n > 0.")

    t3_ok = (s10.set_index("year").loc[2018, "T3"] == 0.02 and s10.set_index("year").loc[2024, "T3"] == 0.08
             and s10.set_index("year").loc[2018, "T11"] == 0.03 and s10.set_index("year").loc[2024, "T11"] == 0.08)
    R.add("C22", "Section 4.5 text (T3 0.02->0.08, T11 0.03->0.08, 2018-2024) matches Table S10",
          "PASS" if t3_ok else "FLAG", "values as reported")

    return R.df()


def report_markdown(df: pd.DataFrame) -> str:
    counts = df["status"].value_counts().to_dict()
    lines = ["# Consistency checks of reported values", "",
             f"Summary: {counts}", "",
             "| id | status | item | detail |", "|---|---|---|---|"]
    for r in df.itertuples():
        lines.append(f"| {r.id} | **{r.status}** | {r.item} | {str(r.detail).replace('|', '/')} |")
    return "\n".join(lines) + "\n"
