"""Corpus loading and schema validation."""
from __future__ import annotations

from pathlib import Path

import pandas as pd

SOURCES = ("FlightGlobal", "ICAO", "GreenAirNews")

REQUIRED_META = ["doc_id", "source", "title", "url", "year", "country_region"]
OPTIONAL_META = ["month", "pub_date", "retrieval_route", "archive_url", "notes"]


class CorpusSchemaError(ValueError):
    pass


def load_corpus(path: str | Path, require_text: bool = True) -> pd.DataFrame:
    """Load the corpus CSV (UTF-8) and validate it against data/README.md."""
    df = pd.read_csv(path, dtype={"doc_id": str}, keep_default_na=False, na_values=[""])
    validate_corpus(df, require_text=require_text)
    df["year"] = df["year"].astype(int)
    return df


def validate_corpus(df: pd.DataFrame, require_text: bool = True) -> None:
    cols = REQUIRED_META + (["text"] if require_text else [])
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise CorpusSchemaError(f"Corpus is missing required columns: {missing}")
    if df["doc_id"].duplicated().any():
        dups = df.loc[df["doc_id"].duplicated(), "doc_id"].tolist()[:5]
        raise CorpusSchemaError(f"doc_id must be unique; duplicates e.g. {dups}")
    bad_src = sorted(set(df["source"]) - set(SOURCES))
    if bad_src:
        raise CorpusSchemaError(f"Unknown source labels {bad_src}; allowed: {SOURCES}")
    if df["year"].isna().any():
        raise CorpusSchemaError("year must be filled for every record")
    yrs = pd.to_numeric(df["year"], errors="coerce")
    if yrs.isna().any() or (yrs < 2007).any() or (yrs > 2025).any():
        raise CorpusSchemaError("year must be an integer in 2007..2025")
    if df["country_region"].isna().any():
        raise CorpusSchemaError("country_region must be filled for every record")
    if require_text and df["text"].isna().any():
        n = int(df["text"].isna().sum())
        raise CorpusSchemaError(f"{n} records have empty text")


def assign_period(years: pd.Series, periods: dict) -> pd.Series:
    """Map publication years to the reporting periods of Table 3."""
    out = pd.Series(index=years.index, dtype=object)
    for label, (lo, hi) in periods.items():
        out[(years >= lo) & (years <= hi)] = label
    if out.isna().any():
        raise ValueError(f"Years outside the defined periods: {sorted(years[out.isna()].unique())}")
    return pd.Categorical(out, categories=list(periods.keys()), ordered=True)
