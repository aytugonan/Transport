"""Configuration loading and run provenance."""
from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

REPO_ROOT = Path(__file__).resolve().parents[2]
ROOT = REPO_ROOT


def load_config(path: str | Path | None = None, **overrides: Any) -> dict:
    """Load the YAML config and resolve all paths relative to the repo root.

    ``overrides`` may set top-level path keys, e.g. ``corpus="data/demo/corpus.csv"``
    or ``outputs="outputs_demo"``.
    """
    path = Path(path) if path else REPO_ROOT / "config" / "config.yaml"
    with open(path, encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh)
    for key, value in overrides.items():
        if value is not None:
            cfg["paths"][key] = value
    for key, value in cfg["paths"].items():
        p = Path(value)
        cfg["paths"][key] = p if p.is_absolute() else REPO_ROOT / p
    cfg["_config_file"] = str(path)
    return cfg


def load_topic_labels(cfg: dict) -> dict:
    with open(cfg["paths"]["topic_labels"], encoding="utf-8") as fh:
        tl = yaml.safe_load(fh)
    tl["mapping"] = {int(k): int(v) for k, v in tl["mapping"].items()}
    tl["labels"] = {int(k): v for k, v in tl["labels"].items()}
    return tl


def out_dir(cfg: dict, *parts: str) -> Path:
    p = Path(cfg["paths"]["outputs"]).joinpath(*parts)
    p.mkdir(parents=True, exist_ok=True)
    return p


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _git_commit() -> str | None:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=REPO_ROOT, stderr=subprocess.DEVNULL, text=True
        ).strip()
    except Exception:
        return None


def package_versions() -> dict:
    import importlib.metadata as md

    names = ["scikit-learn", "gensim", "pandas", "numpy", "scipy", "nltk",
             "matplotlib", "seaborn", "pyLDAvis", "PyYAML"]
    out = {}
    for n in names:
        try:
            out[n] = md.version(n)
        except md.PackageNotFoundError:
            out[n] = None
    return out


def write_run_info(cfg: dict, step: str, extra: dict | None = None) -> Path:
    """Write provenance (versions, hashes, commit) next to the outputs of a step."""
    info = {
        "step": step,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": package_versions(),
        "git_commit": _git_commit(),
        "config_file": cfg["_config_file"],
        "config_sha256": sha256_file(cfg["_config_file"]),
        "corpus_file": str(cfg["paths"]["corpus"]),
        "corpus_sha256": sha256_file(cfg["paths"]["corpus"]) if Path(cfg["paths"]["corpus"]).exists() else None,
    }
    if extra:
        info.update(extra)
    p = out_dir(cfg, "provenance") / f"{step}.json"
    p.write_text(json.dumps(info, indent=2, default=str), encoding="utf-8")
    return p
