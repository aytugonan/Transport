"""Figures 1-6 and S1-S2 (plus a full 20-topic supplementary trajectory panel)."""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import seaborn as sns  # noqa: E402

INK = "#1f2933"
MUTED = "#7b8794"
GRID = "#e4e7eb"
C1, C2, C3 = "#2f6690", "#d9822b", "#3a7d44"
SOURCE_COLORS = {"FlightGlobal": C1, "ICAO": C2, "GreenAirNews": C3}
DEMO_TEXT = "SYNTHETIC DEMO DATA — not the study corpus"


def setup_style():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 10,
        "axes.labelsize": 9, "axes.edgecolor": MUTED, "axes.labelcolor": INK,
        "xtick.color": INK, "ytick.color": INK, "axes.spines.top": False,
        "axes.spines.right": False, "axes.grid": False, "legend.frameon": False,
        "savefig.bbox": "tight",
    })


def _stamp(fig, demo: bool):
    if demo:
        fig.text(0.5, 0.5, DEMO_TEXT, ha="center", va="center", fontsize=16, color="#c62828",
                 alpha=0.18, rotation=20, transform=fig.transFigure, zorder=100)
        fig.text(0.99, 0.995, DEMO_TEXT, ha="right", va="top", fontsize=7, color="#c62828")


def save(fig, outdir: Path, name: str, cfg: dict, demo: bool = False):
    _stamp(fig, demo)
    outdir.mkdir(parents=True, exist_ok=True)
    for ext in cfg["figures"]["format"]:
        fig.savefig(outdir / f"{name}.{ext}", dpi=cfg["figures"]["dpi"])
    plt.close(fig)


def ms_col(ms_topic: int, mapping: dict) -> str:
    """Model column name for a manuscript topic number."""
    inv = {v: k for k, v in mapping.items()}
    return f"topic_{inv[ms_topic]}"


def ms_name(col: str, mapping: dict, labels: dict | None = None, short: bool = True) -> str:
    t = mapping[int(col.split("_")[1])]
    if labels and not short:
        return f"T{t} · {labels.get(t, '')}"
    return f"T{t}"


# --------------------------------------------------------------------------- counts
def fig1_period_counts(counts: pd.Series):
    fig, ax = plt.subplots(figsize=(6.2, 3.0))
    y = np.arange(len(counts))[::-1]
    ax.barh(y, counts.values, color=C1, height=0.62)
    for yi, v in zip(y, counts.values):
        ax.text(v + counts.max() * 0.01, yi, f"{v}", va="center", fontsize=8, color=INK)
    ax.set_yticks(y, [str(i) for i in counts.index])
    ax.set_xlabel("Number of retained articles (period total)")
    ax.set_xlim(0, counts.max() * 1.12)
    ax.set_title(f"Retained articles by reporting period (N = {int(counts.sum())})", loc="left")
    return fig


def fig5_geography(counts: pd.Series):
    counts = counts.sort_values(ascending=True)
    n = counts.sum()
    fig, ax = plt.subplots(figsize=(6.4, 0.26 * len(counts) + 0.8))
    ax.barh(counts.index, counts.values, color=C1, height=0.62)
    for i, v in enumerate(counts.values):
        ax.text(v + n * 0.004, i, f"{v} ({v / n:.1%})", va="center", fontsize=7.5)
    ax.set_xlabel("Number of articles (primary geographical focus)")
    ax.set_xlim(0, counts.max() * 1.22)
    ax.set_title(f"Geographical focus of retained articles (N = {int(n)})", loc="left")
    return fig


def figS1_year_counts(n_by_year: pd.Series, partial_years=(2025,)):
    fig, ax = plt.subplots(figsize=(6.4, 2.6))
    colors = [MUTED if y in partial_years else C1 for y in n_by_year.index]
    ax.bar(n_by_year.index, n_by_year.values, color=colors)
    ax.set_xticks(n_by_year.index, [str(y) for y in n_by_year.index], rotation=90, fontsize=7)
    ax.set_ylabel("Articles (n)")
    ax.set_title("Articles by publication year (grey = partial year)", loc="left")
    return fig


# --------------------------------------------------------------------------- topics
def fig2_cosine_heatmap(S: np.ndarray, labels: list[str]):
    fig, ax = plt.subplots(figsize=(6.0, 5.2))
    sns.heatmap(S, ax=ax, cmap="viridis", vmin=0, vmax=1, square=True,
                xticklabels=labels, yticklabels=labels, linewidths=0,
                cbar_kws={"label": "Cosine similarity", "shrink": 0.8})
    ax.set_xlabel("Topic")
    ax.set_ylabel("Topic")
    ax.tick_params(labelsize=7)
    ax.set_title("Topic–topic cosine similarity of topic–word distributions", loc="left")
    return fig


def fig3_overlap(O: pd.DataFrame, labels: list[str]):
    M = O.to_numpy().astype(float)
    np.fill_diagonal(M, np.nan)
    fig, ax = plt.subplots(figsize=(5.4, 4.2))
    sns.heatmap(M, ax=ax, cmap="Blues", vmin=0, vmax=10, annot=True, fmt=".0f",
                xticklabels=labels, yticklabels=labels, cbar_kws={"label": "Shared top-10 terms"},
                linewidths=0.5, linecolor="white", mask=np.isnan(M))
    ax.tick_params(axis="x", rotation=30, labelsize=7.5)
    ax.tick_params(axis="y", rotation=0, labelsize=7.5)
    ax.set_title("Pairwise overlap of top-10 keyword lists", loc="left")
    return fig


def fig4_trajectories(ma: pd.DataFrame, cols: list[str], names: list[str]):
    fig, ax = plt.subplots(figsize=(6.6, 3.6))
    pal = sns.color_palette("colorblind", len(cols))
    for c, nm, col in zip(cols, names, pal):
        s = ma[c]
        ax.plot(s.index, s.values, marker="o", ms=3, lw=1.6, color=col, label=nm)
    ax.set_xlabel("Publication year (end of 3-year trailing window)")
    ax.set_ylabel("Mean topic proportion (3-yr MA)")
    ax.set_xticks(ma.index, [str(y) for y in ma.index], rotation=90, fontsize=7)
    ax.legend(fontsize=7, ncol=2, loc="upper left", bbox_to_anchor=(0, -0.28))
    ax.set_title("Three-year moving-average trajectories (descriptive, source-mixed)", loc="left")
    ax.grid(axis="y", color=GRID)
    return fig


def fig_all_topics(annual: pd.DataFrame, ci: pd.DataFrame | None, cols: list[str], names: list[str],
                   partial_years=(2025,)):
    """Supplementary: annual means with bootstrap CIs for all topics (answers R3.4)."""
    n = len(cols)
    ncol = 4
    nrow = int(np.ceil(n / ncol))
    fig, axes = plt.subplots(nrow, ncol, figsize=(10, 2.0 * nrow), sharex=True, sharey=True)
    axes = np.atleast_1d(axes).ravel()
    for ax, c, nm in zip(axes, cols, names):
        s = annual[c]
        full = s[~s.index.isin(partial_years)]
        ax.plot(full.index, full.values, color=C1, lw=1.3, marker="o", ms=2)
        part = s[s.index.isin(partial_years)]
        ax.plot(part.index, part.values, ls="none", marker="o", mfc="white", mec=C1, ms=3)
        if ci is not None:
            sub = ci[ci["topic"] == c].set_index("year").reindex(s.index)
            ax.fill_between(sub.index, sub["ci_low"], sub["ci_high"], color=C1, alpha=0.15, lw=0)
        ax.set_title(nm, fontsize=7.5, loc="left")
        ax.grid(axis="y", color=GRID)
        ax.tick_params(labelsize=6.5)
    for ax in axes[n:]:
        ax.axis("off")
    fig.supylabel("Annual mean topic proportion", fontsize=8)
    fig.suptitle("All topics: annual means with 95% document-bootstrap CIs (hollow = partial year)",
                 x=0.01, ha="left", fontsize=9)
    fig.tight_layout()
    return fig


def fig6_propulsion(annual: pd.DataFrame, ci: pd.DataFrame | None, cols: list[str], names: list[str],
                    years: tuple[int, int], partial_years=(2025,)):
    a = annual.loc[years[0]:years[1]]
    fig, (ax, axn) = plt.subplots(2, 1, figsize=(6.6, 4.6), sharex=True,
                                  gridspec_kw={"height_ratios": [2.4, 1]})
    for c, nm, col, mk in zip(cols, names, [C1, C2], ["o", "s"]):
        s = a[c]
        full = s[~s.index.isin(partial_years)]
        ax.plot(full.index, full.values, color=col, marker=mk, ms=4, lw=1.8, label=nm)
        part = s[s.index.isin(partial_years)]
        ax.plot(part.index, part.values, ls="none", marker=mk, ms=5, mfc="white", mec=col)
        if ci is not None:
            sub = ci[ci["topic"] == c].set_index("year").reindex(full.index)
            ax.fill_between(sub.index, sub["ci_low"], sub["ci_high"], color=col, alpha=0.15, lw=0)
    ax.set_ylabel("Mean topic proportion")
    ax.legend(fontsize=8, loc="upper left")
    ax.grid(axis="y", color=GRID)
    ax.set_title("Alternative-propulsion topic visibility (annual means, 95% bootstrap CI)", loc="left")
    axn.bar(a.index, a["n_docs"], color=[MUTED if y in partial_years else "#9aa5b1" for y in a.index])
    for y, v in a["n_docs"].items():
        axn.text(y, v, str(v), ha="center", va="bottom", fontsize=7)
    axn.set_ylabel("Articles (n)")
    axn.set_xlabel("Publication year")
    axn.set_xticks(a.index, [str(y) for y in a.index])
    return fig


def figS2_source_specific(src: pd.DataFrame, cols: list[str], names: list[str], years: tuple[int, int],
                          min_docs: int = 1):
    s = src[(src["year"] >= years[0]) & (src["year"] <= years[1]) & (src["n_docs"] >= min_docs)]
    fig, axes = plt.subplots(1, len(cols), figsize=(4.0 * len(cols), 3.0), sharey=True)
    axes = np.atleast_1d(axes)
    for ax, c, nm in zip(axes, cols, names):
        for source, g in s.groupby("source"):
            ax.plot(g["year"], g[c], marker="o", ms=3, lw=1.4, color=SOURCE_COLORS.get(source), label=source)
        ax.set_title(nm, loc="left")
        ax.set_xlabel("Publication year")
        ax.grid(axis="y", color=GRID)
    axes[0].set_ylabel("Source-specific mean topic proportion")
    axes[-1].legend(fontsize=7)
    return fig
