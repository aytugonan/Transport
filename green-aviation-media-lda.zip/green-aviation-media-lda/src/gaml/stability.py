"""Multi-initialisation stability (Supplementary Tables S6-S8).

Definitions (fixed here so that aggregate and topic-wise summaries are
consistent by construction - see docs/KNOWN_ISSUES.md, item S3):

* For a given K, the reference run is the model with ``reference_seed`` (42).
* Each of the other 9 runs is aligned to the reference by the Hungarian
  algorithm on the K x K cosine-similarity matrix of topic-word distributions.
* ``topic stability`` (Table S7) for reference topic k = mean (SD, min, max)
  over the 9 runs of the matched cosine similarity.
* ``model stability`` (Table S6) = mean ± SD over the 9 runs of each run's
  average matched cosine. Because every run contributes one value per topic,
  the unweighted mean of the Table S7 topic means equals the Table S6 mean.
* A secondary, reference-free summary over all 45 seed pairs is also reported.
"""
from __future__ import annotations

from itertools import combinations

import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment


def cosine_matrix(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    A = A / np.linalg.norm(A, axis=1, keepdims=True)
    B = B / np.linalg.norm(B, axis=1, keepdims=True)
    return A @ B.T


def hungarian_match(ref: np.ndarray, other: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return (perm, sims): other-topic perm[k] matched to ref topic k and its cosine."""
    S = cosine_matrix(ref, other)
    r, c = linear_sum_assignment(-S)
    perm = np.empty(ref.shape[0], dtype=int)
    perm[r] = c
    return perm, S[np.arange(ref.shape[0]), perm]


def reference_stability(betas: dict[int, np.ndarray], reference_seed: int):
    ref = betas[reference_seed]
    per_run = {}
    for seed, beta in betas.items():
        if seed == reference_seed:
            continue
        _, sims = hungarian_match(ref, beta)
        per_run[seed] = sims
    M = np.vstack(list(per_run.values()))            # runs x topics
    topic_tbl = pd.DataFrame({
        "model_topic": np.arange(M.shape[1]),
        "mean_cosine": M.mean(axis=0),
        "sd": M.std(axis=0, ddof=1),
        "min": M.min(axis=0),
        "max": M.max(axis=0),
        "n_runs": M.shape[0],
    })
    run_means = M.mean(axis=1)
    return topic_tbl, float(run_means.mean()), float(run_means.std(ddof=1)), M


def pairwise_stability(betas: dict[int, np.ndarray]) -> tuple[float, float]:
    vals = []
    for a, b in combinations(sorted(betas), 2):
        _, sims = hungarian_match(betas[a], betas[b])
        vals.append(sims.mean())
    vals = np.asarray(vals)
    return float(vals.mean()), float(vals.std(ddof=1))


def paired_bootstrap_delta(cv_k: np.ndarray, cv_ref: np.ndarray, reps: int, seed: int,
                           level: float = 0.95) -> dict:
    """Paired-seed bootstrap of mean C_v difference (K minus reference K)."""
    d = np.asarray(cv_k) - np.asarray(cv_ref)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(d), size=(reps, len(d)))
    boots = d[idx].mean(axis=1)
    lo, hi = np.quantile(boots, [(1 - level) / 2, 1 - (1 - level) / 2])
    return {"delta_cv": float(d.mean()), "ci_low": float(lo), "ci_high": float(hi),
            "ci_includes_zero": bool(lo <= 0 <= hi), "n_seeds": len(d)}
