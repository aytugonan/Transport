"""gaml - Green Aviation Media LDA.

Reproducibility code for "Shifting Media Visibility of Green Air Transport
Technologies: A Text-Mining Study of Specialized Aviation Media (2007-2025)".
"""

__version__ = "1.0.0"
