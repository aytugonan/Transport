"""Temporal summaries and source-composition sensitivity (Sections 3.5, 4.5).

All quantities are computed from one document-topic matrix (doc_topic.csv),
so every temporal figure/table shares the same denominators.

Pooled annual mean for topic k, year t (manuscript Section 3.5):
    theta_bar_{k,t} = sum_s (n_{s,t} / n_t) * theta_bar_{k,s,t}
``decomposition_residual`` verifies this identity numerically.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def topic_cols(dt: pd.DataFrame) -> list[str]:
    return [c for c in dt.columns if c.startswith("topic_")]


# --------------------------------------------------------------------------- annual
def annual_means(dt: pd.DataFrame, year_range: tuple[int, int] = (2007, 2025)) -> pd.DataFrame:
    """Mean document-topic proportion per year; years without documents are NaN."""
    cols = topic_cols(dt)
    g = dt.groupby("year")
    out = g[cols].mean()
    out.insert(0, "n_docs", g.size())
    full = pd.RangeIndex(year_range[0], year_range[1] + 1, name="year")
    out = out.reindex(full)
    out["n_docs"] = out["n_docs"].fillna(0).astype(int)
    return out


def trailing_moving_average(annual: pd.DataFrame, window: int = 3, require_complete: bool = True) -> pd.DataFrame:
    """Trailing MA on the calendar-year index; incomplete windows -> NaN (not zero-filled)."""
    cols = [c for c in annual.columns if c.startswith("topic_")]
    minp = window if require_complete else 1
    ma = annual[cols].rolling(window=window, min_periods=minp).mean()
    ma.insert(0, "n_docs_window", annual["n_docs"].rolling(window, min_periods=1).sum().astype(int))
    return ma


def period_means(dt: pd.DataFrame, period: pd.Series) -> pd.DataFrame:
    cols = topic_cols(dt)
    tmp = dt[cols].copy()
    tmp["period"] = period
    g = tmp.groupby("period", observed=False)
    out = g[cols].mean()
    out.insert(0, "n_docs", g.size())
    return out


def annual_bootstrap_ci(dt: pd.DataFrame, reps: int, seed: int, level: float = 0.95) -> pd.DataFrame:
    """Percentile CIs for annual means by resampling documents within each year."""
    cols = topic_cols(dt)
    rng = np.random.default_rng(seed)
    a = (1 - level) / 2
    rows = []
    for year, grp in dt.groupby("year"):
        T = grp[cols].to_numpy()
        n = T.shape[0]
        idx = rng.integers(0, n, size=(reps, n))
        boots = T[idx].mean(axis=1)                       # reps x K
        lo, hi = np.quantile(boots, [a, 1 - a], axis=0)
        for j, c in enumerate(cols):
            rows.append({"year": year, "topic": c, "n_docs": n, "mean": T[:, j].mean(),
                         "ci_low": lo[j], "ci_high": hi[j]})
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- sources
def source_annual_means(dt: pd.DataFrame) -> pd.DataFrame:
    cols = topic_cols(dt)
    g = dt.groupby(["source", "year"])
    out = g[cols].mean()
    out.insert(0, "n_docs", g.size())
    return out.reset_index()


def source_year_counts(dt: pd.DataFrame) -> pd.DataFrame:
    return dt.pivot_table(index="year", columns="source", values="doc_id", aggfunc="count", fill_value=0)


def decomposition_residual(dt: pd.DataFrame) -> float:
    """max |pooled mean - sum_s w_{s,t} * within-source mean| over years and topics."""
    cols = topic_cols(dt)
    pooled = dt.groupby("year")[cols].mean()
    sm = source_annual_means(dt)
    n_t = sm.groupby("year")["n_docs"].transform("sum")
    weighted = sm[cols].mul(sm["n_docs"] / n_t, axis=0)
    weighted["year"] = sm["year"]
    recon = weighted.groupby("year")[cols].sum()
    return float((pooled - recon).abs().to_numpy().max())


def leave_one_source_out_annual(dt: pd.DataFrame, year_range=(2007, 2025)) -> pd.DataFrame:
    frames = []
    for s in sorted(dt["source"].unique()):
        a = annual_means(dt[dt["source"] != s], year_range)
        a.insert(0, "dropped_source", s)
        frames.append(a.reset_index())
    return pd.concat(frames, ignore_index=True)


# --------------------------------------------------------------------------- trends
def _ols_slope(year: np.ndarray, Y: np.ndarray, sources: np.ndarray | None) -> np.ndarray:
    yc = year - year.mean()
    if sources is None:
        X = np.column_stack([np.ones_like(yc), yc])
    else:
        levels = np.unique(sources)
        D = (sources[:, None] == levels[None, :]).astype(float)
        X = np.column_stack([yc, D])
    beta, *_ = np.linalg.lstsq(X, Y, rcond=None)
    return beta[1] if sources is None else beta[0]


def _sources_identifiable(year: np.ndarray, sources: np.ndarray) -> bool:
    # each source needs >= 2 distinct years for its fixed effect not to absorb the slope
    return all(len(np.unique(year[sources == s])) >= 2 for s in np.unique(sources))


def trend_slopes(dt: pd.DataFrame, window: tuple[int, int], reps: int, seed: int,
                 level: float = 0.95) -> pd.DataFrame:
    """Linear change in topic proportion per year within ``window``.

    pooled   : OLS theta ~ year (the pooled, source-mixed trend)
    source_fe: OLS theta ~ year + source fixed effects (within-source trend,
               removes level differences between outlets / composition change)
    loso_*   : pooled slope after dropping one source
    CIs      : document bootstrap, stratified by source (``reps`` replicates).
    """
    cols = topic_cols(dt)
    w = dt[(dt["year"] >= window[0]) & (dt["year"] <= window[1])].reset_index(drop=True)
    yr = w["year"].to_numpy(float)
    src = w["source"].to_numpy()
    Y = w[cols].to_numpy()
    fe_ok = _sources_identifiable(yr, src)

    pooled = _ols_slope(yr, Y, None)
    fe = _ols_slope(yr, Y, src) if fe_ok else np.full(len(cols), np.nan)

    rng = np.random.default_rng(seed)
    groups = [np.flatnonzero(src == s) for s in np.unique(src)]
    bp, bf = np.empty((reps, len(cols))), np.empty((reps, len(cols)))
    for b in range(reps):
        idx = np.concatenate([g[rng.integers(0, len(g), len(g))] for g in groups])
        bp[b] = _ols_slope(yr[idx], Y[idx], None)
        bf[b] = _ols_slope(yr[idx], Y[idx], src[idx]) if fe_ok else np.nan
    a = (1 - level) / 2

    out = pd.DataFrame({
        "topic": cols,
        "n_docs": len(w),
        "pooled_slope": pooled,
        "pooled_ci_low": np.quantile(bp, a, axis=0),
        "pooled_ci_high": np.quantile(bp, 1 - a, axis=0),
        "source_fe_slope": fe,
        "source_fe_ci_low": np.nanquantile(bf, a, axis=0) if fe_ok else np.nan,
        "source_fe_ci_high": np.nanquantile(bf, 1 - a, axis=0) if fe_ok else np.nan,
    })
    for s in np.unique(src):
        keep = src != s
        out[f"loso_{s}_slope"] = _ols_slope(yr[keep], Y[keep], None) if keep.sum() > 2 else np.nan

    loso = out[[c for c in out.columns if c.startswith("loso_")]].to_numpy()
    sign = np.sign(out["pooled_slope"].to_numpy())[:, None]
    out["loso_same_sign_all"] = (np.sign(loso) == sign).all(axis=1)
    out["pooled_ci_excludes_zero"] = (out["pooled_ci_low"] > 0) | (out["pooled_ci_high"] < 0)
    out["source_fe_ci_excludes_zero"] = (out["source_fe_ci_low"] > 0) | (out["source_fe_ci_high"] < 0)
    out["window"] = f"{window[0]}-{window[1]}"
    return out
