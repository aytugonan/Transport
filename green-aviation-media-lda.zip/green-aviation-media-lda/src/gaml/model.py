"""Vectorisation, LDA estimation, and model artefacts."""
from __future__ import annotations

import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.feature_extraction.text import CountVectorizer

LDA_KEYS = [
    "learning_method", "doc_topic_prior", "topic_word_prior", "max_iter", "batch_size",
    "learning_decay", "learning_offset", "evaluate_every", "total_samples", "perp_tol",
    "mean_change_tol", "max_doc_update_iter", "n_jobs",
]


def build_vectorizer(cfg: dict) -> CountVectorizer:
    v = cfg["vectorizer"]
    return CountVectorizer(
        lowercase=False,
        token_pattern=r"\S+",          # documents arrive as space-joined clean tokens
        min_df=v["min_df"],
        max_df=v["max_df"],
        ngram_range=tuple(v.get("ngram_range", [1, 1])),
    )


def vectorize(token_lists, cfg: dict):
    vec = build_vectorizer(cfg)
    X = vec.fit_transform([" ".join(t) for t in token_lists])
    return vec, X


def make_lda(cfg: dict, n_components: int | None = None, seed: int | None = None) -> LatentDirichletAllocation:
    p = cfg["lda"]
    kwargs = {k: p[k] for k in LDA_KEYS if k in p}
    return LatentDirichletAllocation(
        n_components=int(n_components or p["n_components"]),
        random_state=int(p["random_state"] if seed is None else seed),
        **kwargs,
    )


def fit_lda(X, cfg: dict, n_components: int | None = None, seed: int | None = None):
    lda = make_lda(cfg, n_components, seed)
    lda.fit(X)
    return lda


def topic_word(lda: LatentDirichletAllocation) -> np.ndarray:
    """beta_kw = P(w | z=k): rows of components_ normalised to sum to one."""
    comp = lda.components_
    return comp / comp.sum(axis=1, keepdims=True)


def top_words(beta: np.ndarray, vocab: np.ndarray, n: int = 10) -> list[list[str]]:
    idx = np.argsort(-beta, axis=1)[:, :n]
    return [list(vocab[row]) for row in idx]


def save_model(outdir: Path, lda, vec, X, docs: pd.DataFrame, mapping: dict | None = None, n_top: int = 20) -> None:
    """Persist everything needed to rebuild every table/figure without refitting."""
    outdir.mkdir(parents=True, exist_ok=True)
    vocab = vec.get_feature_names_out()
    beta = topic_word(lda)
    theta = lda.transform(X)
    k = beta.shape[0]

    with open(outdir / "lda_model.pkl", "wb") as fh:
        pickle.dump(lda, fh)
    with open(outdir / "vectorizer.pkl", "wb") as fh:
        pickle.dump(vec, fh)
    sparse.save_npz(outdir / "dtm.npz", sparse.csr_matrix(X))
    pd.Series(vocab, name="term").to_csv(outdir / "vocabulary.csv", index_label="term_id")

    # topic-word probabilities (long format, all terms) - the numbers Table 6 omits
    tw = pd.DataFrame(beta, columns=vocab)
    tw.index.name = "model_topic"
    tw.T.to_csv(outdir / "topic_word_matrix.csv")

    rows = []
    for t in range(k):
        order = np.argsort(-beta[t])[:n_top]
        for rank, j in enumerate(order, 1):
            rows.append({"model_topic": t,
                         "ms_topic": (mapping or {}).get(t, t + 1),
                         "rank": rank, "term": vocab[j], "beta": float(beta[t, j])})
    pd.DataFrame(rows).to_csv(outdir / "top_terms.csv", index=False)

    dt = pd.DataFrame(theta, columns=[f"topic_{t}" for t in range(k)])
    meta_cols = [c for c in ["doc_id", "source", "year", "country_region"] if c in docs.columns]
    dt = pd.concat([docs[meta_cols].reset_index(drop=True), dt], axis=1)
    dt.to_csv(outdir / "doc_topic.csv", index=False)

    (outdir / "model_params.json").write_text(
        json.dumps({k_: (v if isinstance(v, (int, float, str, type(None))) else str(v))
                    for k_, v in lda.get_params().items()}, indent=2),
        encoding="utf-8",
    )
