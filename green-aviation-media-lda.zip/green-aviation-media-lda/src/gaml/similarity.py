"""Inter-topic lexical proximity (Figure 2) and top-N keyword overlap (Figure 3)."""
from __future__ import annotations

from itertools import combinations

import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment

from .stability import cosine_matrix


def topic_cosine_matrix(beta: np.ndarray) -> np.ndarray:
    """Cosine similarity between pooled-corpus topic-word distributions (Figure 2)."""
    return cosine_matrix(beta, beta)


def keyword_overlap(keywords: dict[int, list[str]]) -> pd.DataFrame:
    """O_ij = |W_i ∩ W_j| for the given topic -> keyword-list mapping (Figure 3)."""
    ids = list(keywords)
    sets = {k: set(v) for k, v in keywords.items()}
    M = pd.DataFrame(0, index=ids, columns=ids, dtype=int)
    for i in ids:
        for j in ids:
            M.loc[i, j] = len(sets[i] & sets[j])
    return M


def shared_terms(keywords: dict[int, list[str]]) -> pd.DataFrame:
    rows = []
    for i, j in combinations(keywords, 2):
        s = sorted(set(keywords[i]) & set(keywords[j]))
        rows.append({"topic_i": i, "topic_j": j, "n_shared": len(s), "shared_terms": "; ".join(s)})
    return pd.DataFrame(rows).sort_values("n_shared", ascending=False)


def normalise_keyword(term: str, lemmatizer=None) -> list[str]:
    """Reported keywords -> model tokens ('zero emission' -> ['zero', 'emission'])."""
    toks = [t for t in term.lower().replace("-", " ").split() if t]
    if lemmatizer is not None:
        toks = [lemmatizer.lemmatize(t) for t in toks]
    return toks


def suggest_mapping(model_top: list[list[str]], reported: dict[int, list[str]], lemmatizer=None) -> pd.DataFrame:
    """Align fitted topics to manuscript topics by Jaccard overlap of top-N words (Hungarian)."""
    rep_ids = sorted(reported)
    rep_sets = [set(t for kw in reported[r] for t in normalise_keyword(kw, lemmatizer)) for r in rep_ids]
    mod_sets = [set(ws) for ws in model_top]
    J = np.zeros((len(mod_sets), len(rep_sets)))
    for a, ms in enumerate(mod_sets):
        for b, rs in enumerate(rep_sets):
            J[a, b] = len(ms & rs) / max(1, len(ms | rs))
    r, c = linear_sum_assignment(-J)
    rows = []
    for a, b in zip(r, c):
        rows.append({
            "model_topic": int(a), "suggested_ms_topic": int(rep_ids[b]), "jaccard": round(float(J[a, b]), 3),
            "shared": "; ".join(sorted(mod_sets[a] & rep_sets[b])),
            "model_top_words": "; ".join(model_top[a]),
        })
    return pd.DataFrame(rows).sort_values("model_topic")
