# Reported values (transcribed from the manuscript and supplement)

These CSVs contain the numbers **as printed** in the pre-submission manuscript
(JTRP-D-25-02611R2) and its supplementary material. They are *not* model
outputs. They serve two purposes:

1. `scripts/08_check_reported_values.py` checks their internal consistency
   (no corpus needed);
2. `scripts/09_compare_to_reported.py` places them next to the values the code
   regenerates from the corpus.

| File | Source |
|---|---|
| `table2_corpus_construction.csv` | Table 2 and Section 3.1 bullet list |
| `table3_period_country.csv` | Table 3 |
| `tableS3_country.csv` | Supplementary Table S3 |
| `table5_model_selection.csv` | Table 5 |
| `table6_topics.csv` | Table 6 (top-10 keywords, ranked) |
| `tableS6_multiseed.csv` | Supplementary Table S6 (cited in the main text as "S5") |
| `tableS7_topic_stability.csv` | Supplementary Table S7 (cited in the main text as "S6") |
| `tableS8_bootstrap.csv` | Supplementary Table S8 |
| `tableS10_annual_T3_T11.csv` | Supplementary Table S10 (empty cell = "–") |

Once the manuscript is updated with regenerated numbers, replace these files
with the final printed values so the comparison stays meaningful.
