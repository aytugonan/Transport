"""Unit tests: run with `pytest -q` from the repository root."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from gaml.config import load_config  # noqa: E402
from gaml.stability import hungarian_match, paired_bootstrap_delta, reference_stability  # noqa: E402
from gaml.temporal import annual_means, decomposition_residual, trailing_moving_average, trend_slopes  # noqa: E402
from gaml.similarity import keyword_overlap  # noqa: E402


@pytest.fixture(scope="module")
def cfg():
    return load_config()


# ----------------------------------------------------------------- preprocessing
def test_preprocessing_rules(cfg):
    from gaml.preprocess import Preprocessor

    p = Preprocessor(cfg)
    toks = p.tokenize("Net-zero CO2 emissions: SAF in the EU & UK. See https://x.org or a@b.com "
                      "Read more. Advertisement. Airlines 2050 &amp; A320")
    assert "net" in toks and "zero" in toks                 # hyphen split
    assert "co2" in toks                                     # protected despite digit removal
    assert "emission" in toks and "emissions" not in toks    # WordNet lemmatisation
    assert {"saf", "eu", "uk"} <= set(toks)                  # protected short tokens
    assert "airline" in toks
    assert not any("http" in t or "org" == t for t in toks)  # URL removed
    assert "advertisement" not in toks and "read" not in toks
    assert "2050" not in toks and "amp" not in toks


def test_short_documents_excluded(cfg):
    from gaml.preprocess import preprocess_corpus

    df = pd.DataFrame({"doc_id": ["a", "b", "c"], "source": "ICAO", "year": 2020,
                       "text": ["hydrogen aircraft " * 40, "too short text", "hydrogen aircraft " * 40]})
    kept, excl = preprocess_corpus(df, cfg)
    assert kept["doc_id"].tolist() == ["a"]
    assert set(excl["reason"]) == {"fewer_than_50_valid_tokens", "duplicate_normalised_text"}


# ----------------------------------------------------------------- temporal
def _toy_doc_topic(seed=0):
    rng = np.random.default_rng(seed)
    years = np.r_[np.repeat(2010, 3), np.repeat(2012, 4), np.repeat(2018, 10), np.repeat(2019, 12),
                  np.repeat(2020, 15)]
    src = rng.choice(["FlightGlobal", "ICAO", "GreenAirNews"], size=len(years))
    src[years < 2018] = "FlightGlobal"
    theta = rng.dirichlet(np.ones(4), size=len(years))
    df = pd.DataFrame(theta, columns=[f"topic_{i}" for i in range(4)])
    df.insert(0, "doc_id", [str(i) for i in range(len(years))])
    df.insert(1, "source", src)
    df.insert(2, "year", years)
    return df


def test_missing_years_are_nan_not_zero():
    a = annual_means(_toy_doc_topic(), (2010, 2020))
    assert np.isnan(a.loc[2011, "topic_0"]) and a.loc[2011, "n_docs"] == 0
    ma = trailing_moving_average(a, 3, require_complete=True)
    assert np.isnan(ma.loc[2012, "topic_0"])                 # window 2010-2012 incomplete
    assert not np.isnan(ma.loc[2020, "topic_0"])             # 2018-2020 complete


def test_source_decomposition_identity():
    assert decomposition_residual(_toy_doc_topic()) < 1e-12


def test_trend_slopes_runs():
    out = trend_slopes(_toy_doc_topic(), (2018, 2020), reps=50, seed=1)
    assert len(out) == 4 and out["pooled_ci_low"].le(out["pooled_ci_high"]).all()


# ----------------------------------------------------------------- stability
def test_hungarian_recovers_permutation():
    rng = np.random.default_rng(3)
    ref = rng.dirichlet(np.ones(50), size=6)
    perm = np.array([3, 0, 5, 1, 4, 2])
    other = ref[perm]
    p, sims = hungarian_match(ref, other)
    assert np.allclose(sims, 1.0)
    assert np.array_equal(other[p], ref)


def test_topicwise_mean_equals_aggregate():
    rng = np.random.default_rng(4)
    betas = {s: rng.dirichlet(np.ones(30), size=5) for s in [42, 1, 2, 3]}
    tbl, mean, sd, M = reference_stability(betas, 42)
    assert abs(tbl["mean_cosine"].mean() - mean) < 1e-12


def test_paired_bootstrap_zero_difference():
    r = paired_bootstrap_delta(np.full(10, 0.5), np.full(10, 0.5), 200, 0)
    assert r["delta_cv"] == 0 and r["ci_includes_zero"]


# ----------------------------------------------------------------- similarity / checks
def test_keyword_overlap():
    O = keyword_overlap({1: ["a", "b", "c"], 2: ["b", "c", "d"]})
    assert O.loc[1, 2] == 2 and O.loc[1, 1] == 3


def test_reported_checks_known_findings():
    from nltk.stem import WordNetLemmatizer
    from gaml.checks import run_reported_checks

    df = run_reported_checks(ROOT / "reported", WordNetLemmatizer()).set_index("id")
    assert df.loc["C01", "status"] == "PASS"     # Table 3 arithmetic
    assert df.loc["C12", "status"] == "PASS"     # Figure 3 recomputes from Table 6
    assert df.loc["C17", "status"] == "FLAG"     # 0.702 vs 0.72
    assert df.loc["C21", "status"] == "FLAG"     # missing annual means in S10
