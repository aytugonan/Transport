# Data

## What is (and is not) in this repository

| File | In GitHub? | Why |
|---|---|---|
| `corpus_TEMPLATE.csv` | yes | schema with three example rows (from Supplementary Table S1) |
| `corpus_metadata.csv` *(to be added by the authors)* | **yes** | 408 records: `doc_id, source, title, url, year, month, country_region, retrieval_route, archive_url` — **no `text` column** |
| `corpus.csv` | **no** (`.gitignore`) | the same 408 records **plus** the full article `text`; copyrighted, kept locally |
| `raw/` | no | any scraped HTML / PDFs |
| `demo/corpus_demo.csv` | no (regenerated) | synthetic corpus from `scripts/00_make_demo_corpus.py` |

Full texts from FlightGlobal, GreenAirNews and the pages linked from the ICAO
Technology Tracker are copyrighted and are not redistributed (manuscript, *Data and
Code Availability*). Anyone can rebuild the text column from the URLs in
`corpus_metadata.csv` (FlightGlobal may require a subscription).

## Schema of `corpus.csv`

| column | type | required | content |
|---|---|---|---|
| `doc_id` | str | yes | stable unique id, e.g. `FG0001`, `ICAO0001`, `GAN0001` |
| `source` | str | yes | exactly one of `FlightGlobal`, `ICAO`, `GreenAirNews` |
| `title` | str | yes | headline |
| `url` | str | yes | original URL (for ICAO: the tracker hyperlink) |
| `year` | int | yes | publication year, 2007–2025 |
| `month` | int | no | publication month (needed to document the Jan–Feb 2025 cut-off) |
| `country_region` | str | yes | primary geographical focus as coded by the authors; use the labels of Table S3 (`United States`, `United Kingdom`, `EU`, `Global`, …) |
| `retrieval_route` | str | no | ICAO: `direct` (116) or `verified_substitute` (37); others: `direct` |
| `archive_url` | str | no | Wayback/substitute URL used for recovered ICAO items |
| `text` | str | yes for modelling | full article text as analysed (before preprocessing) |

UTF-8, comma-separated, quoted text fields. `scripts/01_corpus_and_preprocess.py`
validates the schema and stops with an explicit message if something is wrong.

## Derived data that **can** be published (after running the pipeline)

These do not allow the articles to be reconstructed and are what the manuscript
promises as "derived representations":

* `outputs/final_model/doc_topic.csv` — document-topic proportions with `doc_id`, `source`, `year`, `country_region`
* `outputs/final_model/topic_word_matrix.csv`, `top_terms.csv`, `vocabulary.csv`
* `outputs/final_model/dtm.npz` — sparse bag-of-words counts (check publisher terms; usually accepted as non-consumptive derived data)
* all `outputs/tables/`, `outputs/temporal/`, `outputs/source_sensitivity/`, `outputs/multiseed/`, `outputs/figures/`

Do **not** publish `outputs/preprocessing/tokens.jsonl` (ordered tokens ≈ text).
