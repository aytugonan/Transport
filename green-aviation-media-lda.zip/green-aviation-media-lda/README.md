# Green aviation media LDA — reproducibility package

Code, configuration and derived data for

> **Shifting Media Visibility of Green Air Transport Technologies: A Text-Mining
> Study of Specialized Aviation Media (2007–2025).** *Transport Policy*
> (under review, JTRP-D-25-02611).

The package regenerates every table and figure in the article and supplement from
a single corpus file and a single configuration file. It also adds the analyses
the reviewers asked for: multi-seed stability, source-composition sensitivity
(leave-one-source-out, source fixed effects) and bootstrap uncertainty.

---

## Contents

```
config/                 config.yaml (every parameter), topic_labels.yaml, domain stopwords
data/                   schema + template; full texts are NOT distributed (see data/README.md)
reported/               numbers as printed in the manuscript (for checks/comparison only)
src/gaml/               library: preprocessing, LDA, selection, stability, temporal, figures, checks
scripts/                numbered pipeline steps 00–09 and run_all.sh
tests/                  unit tests (pytest)
docs/                   MANUSCRIPT_MAPPING, REVIEWER_RESPONSE_MAP, KNOWN_ISSUES
```

## Installation

Python 3.10 with the exact versions reported in the paper:

```bash
python3.10 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python scripts/setup_nltk.py           # stopwords, wordnet, omw-1.4
pytest -q                              # 10 tests
```

(or `conda env create -f environment.yml`)

## Quick start without the corpus (synthetic demo)

```bash
bash scripts/run_all.sh --demo --quick    # ~1 min, reduced grids
bash scripts/run_all.sh --demo            # full grids, ~8 min on one CPU core
```

This generates a **synthetic** corpus with the same metadata margins as the study
(408 records, Table 3 counts) and random texts, then runs every step into
`outputs_demo/`. All demo figures carry a "SYNTHETIC DEMO DATA" watermark.
Model-based demo numbers mean nothing for the paper; the demo only shows that
the code runs end to end.

## Reproducing the paper

1. Put the corpus at `data/corpus.csv` (schema in [`data/README.md`](data/README.md);
   408 rows; `text` column stays local).
2. Run steps 01–04:
   ```bash
   python scripts/01_corpus_and_preprocess.py
   python scripts/02_model_selection.py
   python scripts/03_multiseed_stability.py
   python scripts/04_fit_final_model.py
   ```
3. Open `outputs/final_model/suggested_topic_mapping.csv` and the top terms.
   Write the agreed mapping (fitted topic → T1…T20) into
   `config/topic_labels.yaml` and **commit it**.
4. Run steps 05–09:
   ```bash
   python scripts/05_temporal_analysis.py
   python scripts/06_source_sensitivity.py --refit
   python scripts/07_similarity.py
   python scripts/08_check_reported_values.py
   python scripts/09_compare_to_reported.py
   ```
   or simply `bash scripts/run_all.sh` once the mapping is in place.

`outputs/checks/reproduced_vs_reported.md` places every regenerated number next
to the printed one. [`docs/MANUSCRIPT_MAPPING.md`](docs/MANUSCRIPT_MAPPING.md)
lists the output file behind each table and figure.

### Pipeline

| Step | Script | Produces |
|---|---|---|
| 00 | `00_make_demo_corpus.py` | synthetic demo corpus |
| 01 | `01_corpus_and_preprocess.py` | schema validation, preprocessing, exclusion log, Tables 3/4/S3/S4, Figures 1/5/S1 |
| 02 | `02_model_selection.py` | Table 5 (C_v, held-out perplexity; K = 5…30) |
| 03 | `03_multiseed_stability.py` | Tables S6–S8 (10 seeds × K = 15…25, Hungarian matching, paired bootstrap) |
| 04 | `04_fit_final_model.py` | final K = 20 model, Table 6 with weights, doc–topic matrix, pyLDAvis |
| 05 | `05_temporal_analysis.py` | annual means, 3-yr MA, bootstrap CIs, Figures 4/6, Table S10, all-topic panel |
| 06 | `06_source_sensitivity.py` | Figure S2, LOSO, source-fixed-effect trends, decomposition check |
| 07 | `07_similarity.py` | Figure 2 (cosine matrix), Figure 3 (keyword overlap) |
| 08 | `08_check_reported_values.py` | consistency checks of the printed numbers (no corpus needed) |
| 09 | `09_compare_to_reported.py` | reproduced vs reported |

Every script accepts `--config`, `--corpus`, `--outputs`, `--topic-labels`
and `--quick`.

## Determinism and provenance

* All LDA settings, including those the original analysis did not archive, are
  fixed in `config/config.yaml`. Undocumented choices are tagged `[DEFAULT]`.
* `n_jobs = 1` and fixed seeds: re-running gives identical numbers on the same
  platform and package versions.
* Each step writes `outputs/provenance/<step>.json`, recording package versions,
  git commit, and SHA-256 of the config and corpus.
* The K = 20, seed-42 run in the multi-seed grid is the same fit as the final
  model, so stability and topic tables refer to identical topics.

## What to publish on GitHub

Commit the code, `config/` (including the final `topic_labels.yaml`),
`reported/` and `docs/`. Also commit `data/corpus_metadata.csv` (the corpus
without its `text` column). After the real run, add `outputs/` **except**
`outputs/preprocessing/tokens.jsonl` (remove the `outputs/*` lines from
`.gitignore`, or copy the outputs to a `results/` folder). Then create a GitHub
release and archive it on Zenodo for a DOI.

## Known issues

[`docs/KNOWN_ISSUES.md`](docs/KNOWN_ISSUES.md) lists the inconsistencies found
in the pre-submission manuscript and supplement, with the step that resolves
each one. Read it before updating the manuscript.

## License

Code: MIT. Derived data: CC BY 4.0. Article texts belong to their publishers
and are not included. Citation: see `CITATION.cff`.
