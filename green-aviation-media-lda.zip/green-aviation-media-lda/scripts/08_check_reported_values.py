"""Step 8 - internal-consistency checks of the numbers reported in the
manuscript and supplement (transcribed in reported/). Needs no corpus.

Outputs: checks/reported_consistency.csv and .md
Exit code is 0 even when FLAGs are found (they are findings, not crashes).
"""
from __future__ import annotations

import _common
from nltk.stem import WordNetLemmatizer

from gaml.checks import report_markdown, run_reported_checks
from gaml.config import ROOT, out_dir


def main():
    args, cfg = _common.setup(__doc__)
    df = run_reported_checks(ROOT / "reported", WordNetLemmatizer())
    cdir = out_dir(cfg, "checks")
    df.to_csv(cdir / "reported_consistency.csv", index=False)
    (cdir / "reported_consistency.md").write_text(report_markdown(df), encoding="utf-8")
    for r in df.itertuples():
        _common.log(f"{r.id} {r.status:<4} {r.item}")
    _common.log(f"summary: {df.status.value_counts().to_dict()} -> {cdir}")


if __name__ == "__main__":
    main()
