"""Step 7 - inter-topic cosine similarity (Figure 2) and keyword overlap (Figure 3).

Figure 3 is produced twice:
  figure3_overlap_model.*     from the fitted model's top-10 terms
  figure3_overlap_reported.*  from the Table 6 keyword strings (manuscript version)

Outputs: similarity/cosine_matrix.csv, similarity/overlap_*.csv, similarity/shared_terms_*.csv
"""
from __future__ import annotations

import _common
import numpy as np
import pandas as pd

from gaml.config import ROOT, load_topic_labels, out_dir, write_run_info
from gaml.figures import fig2_cosine_heatmap, fig3_overlap, save, setup_style
from gaml.similarity import keyword_overlap, shared_terms, topic_cosine_matrix

SHORT = {2: "SAF adoption", 3: "Hydrogen", 8: "EU rules", 10: "Carbon", 14: "Feedstock", 20: "China"}


def main():
    args, cfg = _common.setup(__doc__)
    fm = out_dir(cfg, "final_model")
    meta = pd.read_csv(out_dir(cfg, "preprocessing") / "analytic_corpus_metadata.csv")
    demo = _common.is_demo(meta)
    tl = load_topic_labels(cfg)
    mp = tl["mapping"]
    sdir, fdir = out_dir(cfg, "similarity"), out_dir(cfg, "figures")

    tw = pd.read_csv(fm / "topic_word_matrix.csv", index_col=0)      # terms x model topics
    beta = tw.T.to_numpy()
    order = sorted(range(beta.shape[0]), key=lambda i: mp[i])         # manuscript order T1..T20
    S = topic_cosine_matrix(beta[order])
    names = [f"T{mp[i]}" for i in order]
    pd.DataFrame(S, index=names, columns=names).round(4).to_csv(sdir / "cosine_matrix.csv")
    off = S[~np.eye(len(S), dtype=bool)]
    setup_style()
    save(fig2_cosine_heatmap(S, names), fdir, "figure2_cosine_similarity", cfg, demo)

    sub = cfg["figures"]["figure3_topics"]
    tt = pd.read_csv(fm / "top_terms.csv")
    model_kw = {t: tt[(tt.ms_topic == t) & (tt["rank"] <= 10)].sort_values("rank")["term"].tolist() for t in sub}
    t6 = pd.read_csv(ROOT / "reported" / "table6_topics.csv")
    rep_kw = {t: t6[t6.ms_topic == t].sort_values("rank")["keyword"].str.lower().tolist() for t in sub}
    lab = [f"T{t} · {SHORT.get(t, '')}" for t in sub]
    for tag, kw in [("model", model_kw), ("reported", rep_kw)]:
        O = keyword_overlap(kw)
        O.to_csv(sdir / f"overlap_{tag}.csv")
        shared_terms(kw).to_csv(sdir / f"shared_terms_{tag}.csv", index=False)
        save(fig3_overlap(O, lab), fdir, f"figure3_overlap_{tag}", cfg, demo and tag == "model")

    write_run_info(cfg, "07_similarity", {"offdiag_cosine_mean": float(off.mean()),
                                          "offdiag_cosine_max": float(off.max())})
    _common.log(f"similarity outputs -> {sdir}")


if __name__ == "__main__":
    main()
