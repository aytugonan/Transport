"""Step 6 - source-composition sensitivity (reviewer comments R2.3, R2.5, R2.7).

A. Fixed-topic analyses (use the final model's document-topic matrix):
   * source x year counts and pooled-mean decomposition check
     (pooled annual mean = sum_s w_{s,t} x within-source mean)
   * within-source annual means (Figure S2)
   * leave-one-source-out (LOSO) annual means
   * linear trends in trend_window: pooled vs source fixed-effects slope,
     with source-stratified document-bootstrap CIs, plus LOSO slopes
B. Optional ``--refit``: refit LDA without each source, align topics to the
   final model (Hungarian on topic-word cosine), recompute annual means.

Outputs (outputs/source_sensitivity/ and figures/):
  source_year_counts.csv, decomposition_check.json, source_annual_means.csv,
  loso_annual_means.csv, trend_slopes.csv, [loso_refit_*.csv], figureS2_source_specific.*
"""
from __future__ import annotations

import json

import _common
import numpy as np
import pandas as pd
from scipy import sparse

from gaml.config import load_topic_labels, out_dir, write_run_info
from gaml.figures import figS2_source_specific, ms_col, ms_name, save, setup_style
from gaml.model import fit_lda, topic_word
from gaml.stability import hungarian_match
from gaml.temporal import (annual_means, decomposition_residual, leave_one_source_out_annual,
                           source_annual_means, source_year_counts, topic_cols, trend_slopes)


def extra(p):
    p.add_argument("--refit", action="store_true", help="also refit LDA leaving each source out")


def main():
    args, cfg = _common.setup(__doc__, extra)
    fm = out_dir(cfg, "final_model")
    dt = pd.read_csv(fm / "doc_topic.csv", dtype={"doc_id": str})
    meta = pd.read_csv(out_dir(cfg, "preprocessing") / "analytic_corpus_metadata.csv")
    demo = _common.is_demo(meta)
    tl = load_topic_labels(cfg)
    mp, labels = tl["mapping"], tl["labels"]
    tc = cfg["temporal"]
    sdir = out_dir(cfg, "source_sensitivity")
    rename = {c: ms_name(c, mp) for c in topic_cols(dt)}
    yr = (int(dt.year.min()), int(dt.year.max()))

    source_year_counts(dt).to_csv(sdir / "source_year_counts.csv")
    resid = decomposition_residual(dt)
    (sdir / "decomposition_check.json").write_text(json.dumps(
        {"max_abs_residual": resid, "identity_holds": resid < 1e-10}, indent=2), encoding="utf-8")

    sam = source_annual_means(dt)
    sam.rename(columns=rename).to_csv(sdir / "source_annual_means.csv", index=False)
    leave_one_source_out_annual(dt, yr).rename(columns=rename).to_csv(sdir / "loso_annual_means.csv", index=False)

    ts = trend_slopes(dt, tuple(tc["trend_window"]), tc["bootstrap_reps"], tc["bootstrap_seed"], tc["ci_level"])
    ts.insert(1, "ms_topic", ts["topic"].map(rename))
    ts.insert(2, "label", ts["topic"].map(lambda c: labels.get(mp[int(c.split('_')[1])], "")))
    ts.sort_values("ms_topic", key=lambda s: s.str[1:].astype(int)).round(5).to_csv(sdir / "trend_slopes.csv", index=False)

    setup_style()
    f6 = [ms_col(t, mp) for t in cfg["figures"]["figure6_topics"]]
    save(figS2_source_specific(sam, f6, [ms_name(c, mp, labels, short=False) for c in f6],
                               tuple(tc["trend_window"])),
         out_dir(cfg, "figures"), "figureS2_source_specific", cfg, demo)

    if args.refit:
        X = sparse.load_npz(fm / "dtm.npz").tocsr()
        ref_beta = topic_word(pd.read_pickle(fm / "lda_model.pkl"))
        rows, frames = [], []
        for s in sorted(dt["source"].unique()):
            keep = np.flatnonzero(dt["source"].to_numpy() != s)
            Xs = X[keep]
            nz = np.asarray(Xs.sum(axis=0)).ravel() > 0     # terms absent without s get ~prior mass only
            lda_s = fit_lda(Xs, cfg)
            perm, sims = hungarian_match(ref_beta, topic_word(lda_s))
            theta = lda_s.transform(Xs)[:, perm]           # column k aligned to final-model topic k
            d = dt.iloc[keep][["doc_id", "source", "year"]].reset_index(drop=True)
            d = pd.concat([d, pd.DataFrame(theta, columns=topic_cols(dt))], axis=1)
            a = annual_means(d, yr).rename(columns=rename)
            a.insert(0, "dropped_source", s)
            frames.append(a.reset_index())
            for k, sim in enumerate(sims):
                rows.append({"dropped_source": s, "ms_topic": rename[f"topic_{k}"], "matched_cosine": sim,
                             "n_docs": len(keep), "terms_present": int(nz.sum())})
            _common.log(f"LOSO refit without {s}: mean matched cosine {sims.mean():.3f}")
        pd.concat(frames).to_csv(sdir / "loso_refit_annual_means.csv", index=False)
        pd.DataFrame(rows).round(4).to_csv(sdir / "loso_refit_topic_match.csv", index=False)

    write_run_info(cfg, "06_source_sensitivity", {"decomposition_residual": resid, "refit": args.refit})
    _common.log(f"source-sensitivity outputs -> {sdir} (decomposition residual {resid:.2e})")


if __name__ == "__main__":
    main()
