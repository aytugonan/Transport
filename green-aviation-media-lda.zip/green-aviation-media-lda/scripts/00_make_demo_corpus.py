"""Generate a SYNTHETIC demo corpus so the pipeline can be run end-to-end
without the copyrighted article texts.

* Metadata margins (year, source, country/region counts) follow the reported
  corpus structure (Table 3, Table S10 annual counts, Table 2 source totals),
  so count-based outputs have realistic shape.
* Texts are random bags of words generated from 20 planted topics whose seed
  vocabularies are the Table 6 keywords. They contain NO real article text.
* Every row carries ``synthetic = 1`` and every figure produced from it is
  watermarked. Model-based numbers from the demo are meaningless for the paper.
"""
from __future__ import annotations

import _common  # noqa: F401
import numpy as np
import pandas as pd

from _common import ROOT, log

ANNUAL = {2007: 3, 2008: 3, 2009: 2, 2010: 3, 2011: 2, 2012: 3, 2013: 2, 2014: 3, 2015: 7,
          2016: 8, 2017: 9, 2018: 14, 2019: 6, 2020: 50, 2021: 129, 2022: 69, 2023: 50,
          2024: 42, 2025: 3}
SOURCE_TOTALS = {"FlightGlobal": 223, "ICAO": 153, "GreenAirNews": 32}
SOURCE_ENTRY = {"FlightGlobal": 2007, "ICAO": 2018, "GreenAirNews": 2020}   # staggered entry (R2.3)

FILLER = """aircraft airline airport industry company flight fleet operator market sector
global international national regional government agency programme project plan strategy
announce report statement executive chief officer director president partner agreement
deal contract order deliver delivery service network route passenger cargo customer
development technology system solution capacity demand supply cost price investment
million billion percent year month week today future target goal milestone launch
expect plan aim seek work support include provide enable expand increase reduce improve
new first large small major key significant potential commercial current recent early
european american asian british german french chinese japanese canadian australian""".split()


def planted_topics(rng):
    t6 = pd.read_csv(ROOT / "reported" / "table6_topics.csv")
    topics = []
    for t, g in t6.groupby("ms_topic"):
        words = []
        for kw in g.sort_values("rank")["keyword"]:
            words += kw.lower().replace("-", " ").split()
        words = list(dict.fromkeys(words))
        extra = list(rng.choice(FILLER, size=12, replace=False))
        vocab = words + [w for w in extra if w not in words]
        weights = np.r_[np.linspace(3.0, 1.0, len(words)), np.full(len(vocab) - len(words), 0.4)]
        topics.append((vocab, weights / weights.sum()))
    return topics


def topic_drift(year: int) -> np.ndarray:
    """Planted temporal pattern (purely illustrative)."""
    x = (year - 2007) / 18
    base = np.ones(20)
    base[18] = 3.0 * (1 - x) + 0.2          # T19 early biofuel declines
    base[1] = 0.6 + 2.0 * x                  # T2 SAF adoption rises
    base[7] = 0.3 + 2.0 * max(0, x - 0.5)    # T8 EU regulation late
    base[2] = 0.4 + 1.5 * x                  # T3 hydrogen rises
    base[10] = 0.5 + 1.2 * x                 # T11 electric rises
    return base / base.sum()


def allocate_sources(rng):
    years = np.repeat(list(ANNUAL), list(ANNUAL.values()))
    src = np.array(["FlightGlobal"] * len(years), dtype=object)
    remaining = dict(SOURCE_TOTALS)
    remaining["FlightGlobal"] = 0
    order = rng.permutation(len(years))
    for s in ["ICAO", "GreenAirNews"]:
        cand = [i for i in order if years[i] >= SOURCE_ENTRY[s] and src[i] == "FlightGlobal"]
        pick = cand[: remaining[s]]
        src[pick] = s
    return years, src


def main():
    rng = np.random.default_rng(20250201)
    years, src = allocate_sources(rng)
    t3 = pd.read_csv(ROOT / "reported" / "table3_period_country.csv").set_index("country_region")
    t3 = t3.drop(index="Total")
    s3 = pd.read_csv(ROOT / "reported" / "tableS3_country.csv").set_index("country_region")
    listed = {"USA", "UK", "Germany", "France", "EU", "Global", "China", "Japan", "Singapore",
              "Australia", "Canada", "Brazil", "The Netherlands", "Sweden"}
    alias = {"USA": "United States", "UK": "United Kingdom", "The Netherlands": "Netherlands"}
    others = [c for c in s3.index if c not in {alias.get(x, x) for x in listed}]
    others_pool = list(np.repeat(others, s3.loc[others, "n_articles"].to_numpy()))
    rng.shuffle(others_pool)

    period_of = {y: ("2007–2014" if y <= 2014 else "2015–2019" if y <= 2019 else str(y)) for y in ANNUAL}
    pools = {p: [] for p in t3.columns if p != "Total"}
    for country, row in t3.iterrows():
        for p in pools:
            for _ in range(int(row[p])):
                pools[p].append(country)
    for p in pools:
        rng.shuffle(pools[p])
    countries = []
    for y in years:
        c = pools[period_of[y]].pop()
        if c == "Others*":
            c = others_pool.pop()
        countries.append(alias.get(c, c))

    topics = planted_topics(rng)
    texts = []
    for y in years:
        theta = rng.dirichlet(np.full(20, 0.1) + 3 * topic_drift(int(y)) * 0.5)
        n_words = int(np.clip(rng.normal(215, 57), 90, 420))
        z = rng.choice(20, size=n_words, p=theta)
        words = []
        for k in z:
            vocab, w = topics[k]
            words.append(vocab[rng.choice(len(vocab), p=w)])
        texts.append(" ".join(words).capitalize() + ".")

    df = pd.DataFrame({
        "doc_id": [f"DEMO{i:04d}" for i in range(len(years))],
        "source": src, "title": [f"Synthetic article {i}" for i in range(len(years))],
        "url": [f"https://example.org/synthetic/{i}" for i in range(len(years))],
        "year": years, "month": [int(rng.integers(1, 3)) if y == 2025 else int(rng.integers(1, 13)) for y in years],
        "country_region": countries, "retrieval_route": "synthetic", "synthetic": 1, "text": texts,
    })
    out = ROOT / "data" / "demo" / "corpus_demo.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    log(f"wrote {out} ({len(df)} synthetic records; sources {df.source.value_counts().to_dict()})")


if __name__ == "__main__":
    main()
