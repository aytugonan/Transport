"""Step 9 - side-by-side comparison of reproduced outputs with the reported values.

Run after steps 01-07 on the REAL corpus. Count tables must match exactly;
model-based numbers will match only if the original configuration is
recovered. Wherever they differ, the reproduced value is the one the code
supports and should be reported (see docs/KNOWN_ISSUES.md).

Output: checks/reproduced_vs_reported.md (+ CSVs)
"""
from __future__ import annotations

from pathlib import Path

import _common
import pandas as pd
from nltk.stem import WordNetLemmatizer

from gaml.config import ROOT, load_topic_labels, out_dir
from gaml.similarity import normalise_keyword

REP = ROOT / "reported"


def _md(df: pd.DataFrame, floatfmt="{:.3f}") -> str:
    df = df.copy()
    for c in df.columns:
        if pd.api.types.is_float_dtype(df[c]):
            df[c] = df[c].map(lambda v: "" if pd.isna(v) else floatfmt.format(v))
    head = "| " + " | ".join(map(str, df.columns)) + " |"
    sep = "|" + "---|" * len(df.columns)
    rows = ["| " + " | ".join(map(str, r)) + " |" for r in df.itertuples(index=False)]
    return "\n".join([head, sep, *rows])


def main():
    args, cfg = _common.setup(__doc__)
    T = Path(cfg["paths"]["outputs"]) / "tables"
    cdir = out_dir(cfg, "checks")
    out = ["# Reproduced vs reported values", ""]
    meta = pd.read_csv(out_dir(cfg, "preprocessing") / "analytic_corpus_metadata.csv")
    if _common.is_demo(meta):
        out += ["> **SYNTHETIC DEMO RUN** — differences below are expected and meaningless.", ""]

    # counts ----------------------------------------------------------------
    if (T / "table3_period_country.csv").exists():
        rep = pd.read_csv(REP / "table3_period_country.csv").set_index("country_region")
        rep = rep.rename(index={"USA": "United States", "UK": "United Kingdom", "The Netherlands": "Netherlands"})
        got = pd.read_csv(T / "table3_period_country.csv").set_index("country_region")
        got.columns = rep.columns
        idx = rep.index.union(got.index, sort=False)
        diff = got.reindex(idx).fillna(0).astype(int) - rep.reindex(idx).fillna(0).astype(int)
        n_bad = int((diff != 0).to_numpy().sum())
        out += ["## Table 3 (period × country/region counts)", "",
                f"Cells differing from the manuscript: **{n_bad}** (must be 0).", ""]
        if n_bad:
            out += [_md(diff.reset_index()), ""]
        diff.to_csv(cdir / "table3_diff.csv")

    # Table 5 ---------------------------------------------------------------
    if (T / "table5_model_selection.csv").exists():
        rep = pd.read_csv(REP / "table5_model_selection.csv")
        got = pd.read_csv(T / "table5_model_selection.csv")[["k", "cv", "heldout_perplexity"]]
        m = rep.merge(got, on="k", how="outer", suffixes=("_reported", "_reproduced"))
        out += ["## Table 5 (single-seed model selection)", "", _md(m), ""]
        m.to_csv(cdir / "table5_compare.csv", index=False)

    # Table S6 --------------------------------------------------------------
    if (T / "tableS6_multiseed.csv").exists():
        rep = pd.read_csv(REP / "tableS6_multiseed.csv")
        got = pd.read_csv(T / "tableS6_multiseed.csv")
        cols = ["k", "cv_mean", "perplexity_mean", "stability_mean"]
        m = rep[cols].merge(got[cols + ["stability_pairwise_mean"]], on="k", how="outer",
                            suffixes=("_reported", "_reproduced"))
        out += ["## Table S6 (10-seed diagnostics)", "", _md(m), ""]
        m.to_csv(cdir / "tableS6_compare.csv", index=False)

    # Table S7 --------------------------------------------------------------
    s7 = sorted(T.glob("tableS7_topic_stability_K*.csv"))
    if s7:
        rep = pd.read_csv(REP / "tableS7_topic_stability.csv")
        got = pd.read_csv(s7[0])
        # seed-42 reference run at K=20 is the final model, so model_topic indices coincide
        got["ms_topic"] = got["model_topic"].map(load_topic_labels(cfg)["mapping"])
        got = got[["ms_topic", "mean_cosine", "sd"]]
        m = rep[["ms_topic", "mean_cosine", "sd"]].merge(got, on="ms_topic", suffixes=("_reported", "_reproduced"))
        out += ["## Table S7 (per-topic stability, K = 20)", "", _md(m), "",
                f"Unweighted means: reported {rep.mean_cosine.mean():.3f}, reproduced {got.mean_cosine.mean():.3f}", ""]
        m.to_csv(cdir / "tableS7_compare.csv", index=False)

    # Table S10 -------------------------------------------------------------
    if (T / "tableS10_annual_T3_T11.csv").exists():
        rep = pd.read_csv(REP / "tableS10_annual_T3_T11.csv")
        got = pd.read_csv(T / "tableS10_annual_T3_T11.csv")
        m = rep.merge(got[["year", "n_docs", "T3", "T11"]], on="year", how="outer", suffixes=("_reported", "_reproduced"))
        out += ["## Table S10 (annual T3 / T11)", "", _md(m), ""]
        m.to_csv(cdir / "tableS10_compare.csv", index=False)

    # Table 6 ---------------------------------------------------------------
    rep_path = T / "table6_reproduced.csv"
    if rep_path.exists():
        lem = WordNetLemmatizer()
        rep = pd.read_csv(REP / "table6_topics.csv")
        got = pd.read_csv(rep_path)
        rows = []
        for t in sorted(rep.ms_topic.unique()):
            a = {w for kw in rep[rep.ms_topic == t].keyword for w in normalise_keyword(kw, lem)}
            b = set(got[got.ms_topic == t].term)
            rows.append({"ms_topic": t, "jaccard": len(a & b) / max(1, len(a | b)),
                         "only_reported": "; ".join(sorted(a - b)), "only_reproduced": "; ".join(sorted(b - a))})
        m = pd.DataFrame(rows)
        out += ["## Table 6 (top-10 keywords; after config/topic_labels.yaml mapping)", "", _md(m), ""]
        m.to_csv(cdir / "table6_compare.csv", index=False)

    (cdir / "reproduced_vs_reported.md").write_text("\n".join(out), encoding="utf-8")
    _common.log(f"comparison -> {cdir / 'reproduced_vs_reported.md'}")


if __name__ == "__main__":
    main()
