"""Step 4 - fit the reported working model (K = 20, seed 42) and export artefacts.

Outputs (outputs/final_model/):
  lda_model.pkl, vectorizer.pkl, dtm.npz, vocabulary.csv
  topic_word_matrix.csv        P(w | z = k) for every term (the weights Table 6 omits)
  top_terms.csv                top-20 terms per topic with beta and rank
  doc_topic.csv                document-topic proportions + doc_id/source/year/country
  suggested_topic_mapping.csv  fitted topic -> manuscript topic (Jaccard vs Table 6)
  table6_reproduced.csv        top-10 keywords per manuscript topic, with weights
  pyldavis.html                (if pyLDAvis is installed)
"""
from __future__ import annotations

import _common
import pandas as pd
from nltk.stem import WordNetLemmatizer

from gaml.config import ROOT, load_topic_labels, out_dir, write_run_info
from gaml.model import fit_lda, save_model, top_words, topic_word, vectorize
from gaml.similarity import suggest_mapping


def extra(p):
    p.add_argument("--write-mapping", default=None,
                   help="write a topic_labels YAML using the suggested mapping (e.g. for the demo)")


def main():
    args, cfg = _common.setup(__doc__, extra)
    doc_ids, tokens = _common.load_tokens(cfg)
    meta = pd.read_csv(out_dir(cfg, "preprocessing") / "analytic_corpus_metadata.csv", dtype={"doc_id": str})
    meta = meta.set_index("doc_id").loc[doc_ids].reset_index()
    vec, X = vectorize(tokens, cfg)
    lda = fit_lda(X, cfg)
    tl = load_topic_labels(cfg)
    fdir = out_dir(cfg, "final_model")
    save_model(fdir, lda, vec, X, meta, tl["mapping"])

    vocab = vec.get_feature_names_out()
    beta = topic_word(lda)

    # convergence / degenerate-topic diagnostic (see docs/KNOWN_ISSUES.md, item M2)
    theta = lda.transform(X)
    prev = pd.DataFrame({"model_topic": range(theta.shape[1]),
                         "ms_topic": [tl["mapping"][i] for i in range(theta.shape[1])],
                         "mean_proportion": theta.mean(axis=0),
                         "docs_dominant": pd.Series(theta.argmax(axis=1)).value_counts()
                                            .reindex(range(theta.shape[1]), fill_value=0).to_numpy()})
    prev.to_csv(fdir / "topic_prevalence.csv", index=False)
    n_dead = int((prev.mean_proportion < 0.005).sum())
    if n_dead:
        _common.log(f"WARNING: {n_dead} topic(s) have mean proportion < 0.005 (degenerate). "
                    "Check topic_prevalence.csv; consider lda.max_iter / learning_method sensitivity.")
    t6 = pd.read_csv(ROOT / "reported" / "table6_topics.csv")
    reported = {int(t): g.sort_values("rank")["keyword"].tolist() for t, g in t6.groupby("ms_topic")}
    sm = suggest_mapping(top_words(beta, vocab, 10), reported, WordNetLemmatizer())
    sm.to_csv(fdir / "suggested_topic_mapping.csv", index=False)

    if args.write_mapping:
        import yaml

        new = dict(tl)
        new["mapping"] = {int(r.model_topic): int(r.suggested_ms_topic) for r in sm.itertuples()}
        with open(args.write_mapping, "w", encoding="utf-8") as fh:
            fh.write("# AUTO-GENERATED from suggested_topic_mapping.csv - review before use\n")
            yaml.safe_dump(new, fh, sort_keys=False, allow_unicode=True)
        tl = new
        tt0 = pd.read_csv(fdir / "top_terms.csv")
        tt0["ms_topic"] = tt0["model_topic"].map(tl["mapping"])
        tt0.to_csv(fdir / "top_terms.csv", index=False)
        _common.log(f"wrote suggested mapping to {args.write_mapping}")

    tt = pd.read_csv(fdir / "top_terms.csv")
    t6r = tt[tt["rank"] <= 10].copy()
    t6r["label"] = t6r["ms_topic"].map(tl["labels"])
    t6r.sort_values(["ms_topic", "rank"]).to_csv(out_dir(cfg, "tables") / "table6_reproduced.csv", index=False)

    try:
        import pyLDAvis
        import pyLDAvis.lda_model as plm

        vis = plm.prepare(lda, X, vec, mds="tsne" if X.shape[0] > 50 else "pcoa", sort_topics=False)
        pyLDAvis.save_html(vis, str(fdir / "pyldavis.html"))
    except Exception as exc:  # optional
        _common.log(f"pyLDAvis export skipped ({exc.__class__.__name__}: {exc})")

    write_run_info(cfg, "04_fit_final_model", {"n_docs": X.shape[0], "n_terms": X.shape[1],
                                               "n_iter_": int(lda.n_iter_), "bound": float(lda.bound_),
                                               "n_degenerate_topics": n_dead})
    _common.log(f"final model: {X.shape[0]} docs x {X.shape[1]} terms, K = {beta.shape[0]}; "
                f"mean Jaccard vs Table 6 = {sm.jaccard.mean():.2f}. Review suggested_topic_mapping.csv "
                "and update config/topic_labels.yaml, then re-run steps 05-07.")


if __name__ == "__main__":
    main()
