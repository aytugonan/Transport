"""Shared CLI plumbing for the numbered pipeline scripts."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from gaml.config import load_config  # noqa: E402


def parser(description: str) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=description)
    p.add_argument("--config", default=None, help="YAML config (default: config/config.yaml)")
    p.add_argument("--corpus", default=None, help="override paths.corpus")
    p.add_argument("--outputs", default=None, help="override paths.outputs")
    p.add_argument("--topic-labels", default=None, help="override paths.topic_labels (YAML mapping)")
    p.add_argument("--quick", action="store_true",
                   help="reduced grids/replicates for smoke tests (results NOT for reporting)")
    return p


def setup(description: str, extra=None):
    p = parser(description)
    if extra:
        extra(p)
    args = p.parse_args()
    cfg = load_config(args.config, corpus=args.corpus, outputs=args.outputs,
                      topic_labels=args.topic_labels)
    if args.quick:
        cfg["model_selection"]["k_grid"] = [5, 10, 20]
        cfg["multiseed"]["k_grid"] = [19, 20, 21]
        cfg["multiseed"]["seeds"] = [42, 1, 2]
        cfg["multiseed"]["bootstrap_reps"] = 500
        cfg["temporal"]["bootstrap_reps"] = 200
    return args, cfg


def load_tokens(cfg):
    path = Path(cfg["paths"]["outputs"]) / "preprocessing" / "tokens.jsonl"
    if not path.exists():
        sys.exit(f"{path} not found - run scripts/01_corpus_and_preprocess.py first")
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
    return [r["doc_id"] for r in rows], [r["tokens"] for r in rows]


def is_demo(df) -> bool:
    return "synthetic" in df.columns and bool(df["synthetic"].astype(int).any())


def log(msg: str):
    print(f"[gaml] {msg}", flush=True)
