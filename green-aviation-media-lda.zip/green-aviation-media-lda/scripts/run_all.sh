#!/usr/bin/env bash
# Run the full pipeline.
#   bash scripts/run_all.sh                       # real corpus (data/corpus.csv)
#   bash scripts/run_all.sh --demo                # synthetic demo corpus -> outputs_demo/
#   bash scripts/run_all.sh --demo --quick        # fast smoke test (reduced grids)
set -euo pipefail
cd "$(dirname "$0")/.."

ARGS=()
DEMO=0
for a in "$@"; do
  case "$a" in
    --demo) DEMO=1 ;;
    *) ARGS+=("$a") ;;
  esac
done
if [[ $DEMO -eq 1 ]]; then
  python scripts/00_make_demo_corpus.py
  ARGS+=(--corpus data/demo/corpus_demo.csv --outputs outputs_demo)
fi
MAP_ARGS=()
if [[ $DEMO -eq 1 ]]; then
  mkdir -p outputs_demo
  MAP_ARGS=(--topic-labels outputs_demo/topic_labels_demo.yaml)
fi

python scripts/01_corpus_and_preprocess.py "${ARGS[@]}"
python scripts/02_model_selection.py       "${ARGS[@]}"
python scripts/03_multiseed_stability.py   "${ARGS[@]}"
if [[ $DEMO -eq 1 ]]; then
  python scripts/04_fit_final_model.py     "${ARGS[@]}" --write-mapping outputs_demo/topic_labels_demo.yaml
else
  python scripts/04_fit_final_model.py     "${ARGS[@]}"
fi
python scripts/05_temporal_analysis.py     "${ARGS[@]}" ${MAP_ARGS[@]+"${MAP_ARGS[@]}"}
python scripts/06_source_sensitivity.py    "${ARGS[@]}" --refit ${MAP_ARGS[@]+"${MAP_ARGS[@]}"}
python scripts/07_similarity.py            "${ARGS[@]}" ${MAP_ARGS[@]+"${MAP_ARGS[@]}"}
python scripts/08_check_reported_values.py "${ARGS[@]}"
python scripts/09_compare_to_reported.py   "${ARGS[@]}" ${MAP_ARGS[@]+"${MAP_ARGS[@]}"}
echo "[gaml] done."
