"""Step 5 - pooled temporal summaries (Figures 4, 6; Table S10; all-topic panel).

Uses outputs/final_model/doc_topic.csv only, so every temporal number shares
one document-topic matrix and one set of denominators.

Outputs:
  temporal/annual_means.csv            year x topic (+ n_docs); missing years = NaN
  temporal/moving_average_3yr.csv      trailing 3-year MA, incomplete windows = NaN
  temporal/period_means.csv            Table 3 periods x topic
  temporal/annual_bootstrap_ci.csv     95% document-bootstrap CIs per year x topic
  tables/tableS10_annual_T3_T11.csv    reproduction of Table S10 (all years with n > 0)
  figures/figure4_trajectories.*, figure6_propulsion.*, figureS3_all_topics.*
"""
from __future__ import annotations

import _common
import pandas as pd

from gaml.config import load_topic_labels, out_dir, write_run_info
from gaml.figures import fig4_trajectories, fig6_propulsion, fig_all_topics, ms_col, ms_name, save, setup_style
from gaml.io import assign_period
from gaml.temporal import annual_bootstrap_ci, annual_means, period_means, topic_cols, trailing_moving_average


def main():
    args, cfg = _common.setup(__doc__)
    dt = pd.read_csv(out_dir(cfg, "final_model") / "doc_topic.csv", dtype={"doc_id": str})
    meta = pd.read_csv(out_dir(cfg, "preprocessing") / "analytic_corpus_metadata.csv")
    demo = _common.is_demo(meta)
    tl = load_topic_labels(cfg)
    mp, labels = tl["mapping"], tl["labels"]
    tc = cfg["temporal"]
    tdir, fdir, odir = out_dir(cfg, "temporal"), out_dir(cfg, "figures"), out_dir(cfg, "tables")

    yr = (int(dt.year.min()), int(dt.year.max()))
    annual = annual_means(dt, yr)
    ma = trailing_moving_average(annual, tc["moving_average_window"], tc["ma_require_complete_window"])
    per = period_means(dt, assign_period(dt["year"], cfg["corpus"]["periods"]))
    ci = annual_bootstrap_ci(dt, tc["bootstrap_reps"], tc["bootstrap_seed"], tc["ci_level"])

    rename = {c: ms_name(c, mp) for c in topic_cols(dt)}
    annual.rename(columns=rename).to_csv(tdir / "annual_means.csv")
    ma.rename(columns=rename).to_csv(tdir / "moving_average_3yr.csv")
    per.rename(columns=rename).to_csv(tdir / "period_means.csv")
    ci.assign(ms_topic=ci["topic"].map(rename)).to_csv(tdir / "annual_bootstrap_ci.csv", index=False)

    # Table S10 reproduction: every year with documents has an estimate
    c3, c11 = ms_col(3, mp), ms_col(11, mp)
    s10 = annual[["n_docs", c3, c11]].rename(columns={c3: "T3", c11: "T11"})
    ci_w = ci.pivot(index="year", columns="topic", values=["ci_low", "ci_high"])
    for name, c in [("T3", c3), ("T11", c11)]:
        s10[f"{name}_ci_low"] = ci_w[("ci_low", c)]
        s10[f"{name}_ci_high"] = ci_w[("ci_high", c)]
    s10.round(4).to_csv(odir / "tableS10_annual_T3_T11.csv")

    setup_style()
    f4 = [ms_col(t, mp) for t in cfg["figures"]["figure4_topics"]]
    save(fig4_trajectories(ma, f4, [ms_name(c, mp, labels, short=False) for c in f4]),
         fdir, "figure4_trajectories", cfg, demo)
    f6 = [ms_col(t, mp) for t in cfg["figures"]["figure6_topics"]]
    save(fig6_propulsion(annual, ci, f6, [ms_name(c, mp, labels, short=False) for c in f6],
                         tuple(cfg["figures"]["figure6_years"]), tc["partial_years"]),
         fdir, "figure6_propulsion", cfg, demo)
    allc = sorted(topic_cols(dt), key=lambda c: mp[int(c.split("_")[1])])
    save(fig_all_topics(annual, ci, allc, [ms_name(c, mp, labels, short=False)[:48] for c in allc],
                        tc["partial_years"]), fdir, "figureS3_all_topics", cfg, demo)

    write_run_info(cfg, "05_temporal_analysis", {"years": yr})
    _common.log(f"temporal outputs -> {tdir}")


if __name__ == "__main__":
    main()
