"""Step 3 - ten-seed diagnostics over K = 15..25 (Tables S6, S7, S8).

Per (K, seed): C_v, held-out perplexity, topic-word matrix (saved, so the
aggregation can be audited - the item missing in the original archive).

Outputs:
  multiseed/runs.csv                       one row per (K, seed)
  multiseed/betas_K{K}.npz                 topic-word matrices of every seed
  tables/tableS6_multiseed.csv             mean ± SD per K (+ pairwise stability)
  tables/tableS7_topic_stability_K20.csv   per-topic matched cosine (reference = seed 42)
  multiseed/matched_cosine_K20_runs.csv    runs x topics matrix behind Table S7
  tables/tableS8_paired_bootstrap.csv      ΔC_v vs K=20 with paired-seed bootstrap CI
"""
from __future__ import annotations

import _common
import numpy as np
import pandas as pd

from gaml.config import load_topic_labels, out_dir, write_run_info
from gaml.model import vectorize
from gaml.selection import CoherenceScorer, evaluate_k, heldout_split
from gaml.stability import paired_bootstrap_delta, pairwise_stability, reference_stability


def main():
    args, cfg = _common.setup(__doc__)
    _, tokens = _common.load_tokens(cfg)
    vec, X = vectorize(tokens, cfg)
    vocab = vec.get_feature_names_out()
    ms, mu = cfg["model_selection"], cfg["multiseed"]
    train, test = heldout_split(X.shape[0], ms["heldout_fraction"], ms["heldout_seed"])
    scorer = CoherenceScorer(tokens, ms["coherence_topn"])
    mdir = out_dir(cfg, "multiseed")
    tdir = out_dir(cfg, "tables")

    runs, summary = [], []
    cv_by_k = {}
    for k in mu["k_grid"]:
        betas = {}
        for seed in mu["seeds"]:
            r = evaluate_k(X, vocab, scorer, cfg, k, seed, train, test)
            betas[seed] = r["beta"]
            runs.append({"k": k, "seed": seed, "cv": r["cv"], "heldout_perplexity": r["heldout_perplexity"]})
        np.savez_compressed(mdir / f"betas_K{k}.npz", **{f"seed_{s}": b for s, b in betas.items()})
        rk = pd.DataFrame([x for x in runs if x["k"] == k])
        topic_tbl, st_mean, st_sd, M = reference_stability(betas, mu["reference_seed"])
        pw_mean, pw_sd = pairwise_stability(betas)
        cv_by_k[k] = rk.set_index("seed").loc[mu["seeds"], "cv"].to_numpy()
        summary.append({
            "k": k, "n_seeds": len(mu["seeds"]),
            "cv_mean": rk.cv.mean(), "cv_sd": rk.cv.std(ddof=1),
            "perplexity_mean": rk.heldout_perplexity.mean(), "perplexity_sd": rk.heldout_perplexity.std(ddof=1),
            "stability_mean": st_mean, "stability_sd": st_sd,
            "stability_topicwise_mean": topic_tbl["mean_cosine"].mean(),   # equals stability_mean by construction
            "stability_pairwise_mean": pw_mean, "stability_pairwise_sd": pw_sd,
        })
        if k == cfg["lda"]["n_components"]:
            tl = load_topic_labels(cfg)
            topic_tbl.insert(1, "ms_topic", topic_tbl["model_topic"].map(tl["mapping"]))
            topic_tbl.sort_values("ms_topic").to_csv(tdir / f"tableS7_topic_stability_K{k}.csv", index=False)
            pd.DataFrame(M, index=[s for s in mu["seeds"] if s != mu["reference_seed"]],
                         columns=[f"topic_{i}" for i in range(k)]).rename_axis("seed").to_csv(
                mdir / f"matched_cosine_K{k}_runs.csv")
        _common.log(f"K={k:>2}  C_v={rk.cv.mean():.3f}±{rk.cv.std(ddof=1):.3f}  "
                    f"perp={rk.heldout_perplexity.mean():.0f}  stability={st_mean:.3f}±{st_sd:.3f}")

    pd.DataFrame(runs).to_csv(mdir / "runs.csv", index=False)
    pd.DataFrame(summary).round(4).to_csv(tdir / "tableS6_multiseed.csv", index=False)

    ref_k = mu["contrasts_vs"]
    rows = []
    for k in mu["k_grid"]:
        if k == ref_k:
            continue
        b = paired_bootstrap_delta(cv_by_k[k], cv_by_k[ref_k], mu["bootstrap_reps"], mu["bootstrap_seed"])
        rows.append({"k": k, "vs_k": ref_k, **b})
    pd.DataFrame(rows).round(4).to_csv(tdir / "tableS8_paired_bootstrap.csv", index=False)
    write_run_info(cfg, "03_multiseed_stability", {"k_grid": mu["k_grid"], "seeds": mu["seeds"]})


if __name__ == "__main__":
    main()
