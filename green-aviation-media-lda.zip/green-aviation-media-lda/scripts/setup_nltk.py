"""Download the NLTK resources used in preprocessing (run once)."""
import nltk

for pkg in ["stopwords", "wordnet", "omw-1.4"]:
    ok = nltk.download(pkg, quiet=True)
    print(f"{pkg}: {'ok' if ok else 'FAILED'}")
