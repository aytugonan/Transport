"""Step 2 - single-initialisation model selection over K (Table 5).

For each K in model_selection.k_grid (seed = lda.random_state):
  * C_v coherence (Gensim) of the model fitted to all documents
  * held-out perplexity (sklearn) of a model fitted to the training split,
    evaluated on the fixed held-out split (model_selection.heldout_*)

Outputs: tables/table5_model_selection.csv, model_selection/heldout_split.csv
"""
from __future__ import annotations

import _common
import pandas as pd

from gaml.config import out_dir, write_run_info
from gaml.model import vectorize
from gaml.selection import CoherenceScorer, evaluate_k, heldout_split


def main():
    args, cfg = _common.setup(__doc__)
    doc_ids, tokens = _common.load_tokens(cfg)
    vec, X = vectorize(tokens, cfg)
    vocab = vec.get_feature_names_out()
    ms = cfg["model_selection"]
    train, test = heldout_split(X.shape[0], ms["heldout_fraction"], ms["heldout_seed"])
    mdir = out_dir(cfg, "model_selection")
    pd.DataFrame({"doc_id": doc_ids, "split": ["train" if i in set(train) else "test" for i in range(len(doc_ids))]}
                 ).to_csv(mdir / "heldout_split.csv", index=False)

    scorer = CoherenceScorer(tokens, ms["coherence_topn"])
    seed = cfg["lda"]["random_state"]
    rows = []
    for k in ms["k_grid"]:
        r = evaluate_k(X, vocab, scorer, cfg, k, seed, train, test)
        rows.append({"k": k, "seed": seed, "cv": round(r["cv"], 4),
                     "heldout_perplexity": round(r["heldout_perplexity"], 1)})
        _common.log(f"K={k:>2}  C_v={r['cv']:.3f}  held-out perplexity={r['heldout_perplexity']:.1f}")
    out = pd.DataFrame(rows)
    out.to_csv(out_dir(cfg, "tables") / "table5_model_selection.csv", index=False)
    write_run_info(cfg, "02_model_selection", {"n_docs": X.shape[0], "n_terms": X.shape[1],
                                                "n_train": len(train), "n_test": len(test)})


if __name__ == "__main__":
    main()
