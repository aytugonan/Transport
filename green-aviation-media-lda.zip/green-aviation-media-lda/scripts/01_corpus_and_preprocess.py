"""Step 1 - validate corpus, preprocess, corpus tables (Tables 3, 4, S3, S4) and
count figures (Figures 1, 5, S1).

Outputs (outputs/):
  preprocessing/tokens.jsonl        token lists (LOCAL ONLY - reconstructs text; gitignored)
  preprocessing/exclusions.csv      every excluded record with its reason
  preprocessing/summary.json        counts at each step
  tables/table3_period_country.csv  period x country/region counts
  tables/tableS3_country.csv        country/region counts and %
  tables/tableS4_period_totals.csv
  tables/source_by_year.csv         source x year counts (the cross-tab Table 3 lacks)
  tables/table4_descriptives.csv
  figures/figure1_period_counts.*, figure5_geography.*, figureS1_year_counts.*
"""
from __future__ import annotations

import json

import _common
import pandas as pd

from gaml.config import out_dir, write_run_info
from gaml.figures import fig1_period_counts, fig5_geography, figS1_year_counts, save, setup_style
from gaml.io import assign_period, load_corpus
from gaml.preprocess import preprocess_corpus

TABLE3_ORDER = ["United States", "United Kingdom", "Germany", "France", "EU", "Global", "China",
                "Japan", "Singapore", "Australia", "Canada", "Brazil", "Netherlands", "Sweden"]


def main():
    args, cfg = _common.setup(__doc__)
    df = load_corpus(cfg["paths"]["corpus"])
    demo = _common.is_demo(df)
    _common.log(f"loaded {len(df)} records from {cfg['paths']['corpus']}" + (" [SYNTHETIC DEMO]" if demo else ""))

    kept, excl = preprocess_corpus(df, cfg)
    pdir = out_dir(cfg, "preprocessing")
    with open(pdir / "tokens.jsonl", "w", encoding="utf-8") as fh:
        for r in kept.itertuples():
            fh.write(json.dumps({"doc_id": r.doc_id, "tokens": r.tokens}) + "\n")
    excl.to_csv(pdir / "exclusions.csv", index=False)
    meta_cols = [c for c in kept.columns if c not in ("text", "tokens")]
    kept[meta_cols].to_csv(pdir / "analytic_corpus_metadata.csv", index=False)

    summary = {
        "records_loaded": len(df), "records_excluded": len(excl),
        "excluded_by_reason": excl["reason"].value_counts().to_dict(),
        "analytic_corpus_n": len(kept), "expected_n": cfg["corpus"]["expected_n_docs"],
        "by_source": kept["source"].value_counts().to_dict(),
    }
    (pdir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    if len(kept) != cfg["corpus"]["expected_n_docs"]:
        _common.log(f"WARNING: analytic corpus has {len(kept)} documents, manuscript reports "
                    f"{cfg['corpus']['expected_n_docs']}. See preprocessing/exclusions.csv.")

    # ------------------------------------------------------------------ tables
    tdir = out_dir(cfg, "tables")
    kept["period"] = assign_period(kept["year"], cfg["corpus"]["periods"])
    t3 = pd.crosstab(kept["country_region"], kept["period"], dropna=False)
    listed = [c for c in TABLE3_ORDER if c in t3.index]
    others = t3.loc[[c for c in t3.index if c not in listed]].sum().rename("Others*")
    t3_out = pd.concat([t3.loc[listed], others.to_frame().T])
    t3_out["Total"] = t3_out.sum(axis=1)
    t3_out.loc["Total"] = t3_out.sum()
    t3_out.index.name = "country_region"
    t3_out.to_csv(tdir / "table3_period_country.csv")

    s3 = kept["country_region"].value_counts().rename("n_articles").to_frame()
    s3["pct"] = (s3["n_articles"] / s3["n_articles"].sum() * 100).round(1)
    s3.index.name = "country_region"
    s3.to_csv(tdir / "tableS3_country.csv")

    s4 = kept["period"].value_counts(sort=False).rename("n_documents")
    s4.index.name = "period"
    s4.to_csv(tdir / "tableS4_period_totals.csv")

    pd.crosstab(kept["year"], kept["source"], margins=True, margins_name="Total").to_csv(tdir / "source_by_year.csv")

    t4 = pd.DataFrame({
        "attribute": ["Total articles", "Time span", "Countries/regions represented",
                      "Average article length (words, raw text)", "SD article length (words)",
                      "Average valid tokens after preprocessing", "Vocabulary size (after min_df/max_df)"],
        "value": [len(kept), f"{kept.year.min()}–{kept.year.max()}", kept["country_region"].nunique(),
                  round(kept["n_words_raw"].mean(), 1), round(kept["n_words_raw"].std(), 1),
                  round(kept["n_tokens"].mean(), 1), "see step 04"],
    })
    t4.to_csv(tdir / "table4_descriptives.csv", index=False)

    # ------------------------------------------------------------------ figures
    setup_style()
    fdir = out_dir(cfg, "figures")
    save(fig1_period_counts(s4), fdir, "figure1_period_counts", cfg, demo)
    geo = t3_out.drop(index="Total")["Total"].rename(index={"Others*": "Other countries / regions"})
    save(fig5_geography(geo), fdir, "figure5_geography", cfg, demo)
    by_year = kept["year"].value_counts().sort_index()
    save(figS1_year_counts(by_year, cfg["temporal"]["partial_years"]), fdir, "figureS1_year_counts", cfg, demo)

    write_run_info(cfg, "01_corpus_and_preprocess", {"summary": summary, "demo": demo})
    _common.log(f"analytic corpus N = {len(kept)}; excluded {len(excl)}; tables -> {tdir}")


if __name__ == "__main__":
    main()
