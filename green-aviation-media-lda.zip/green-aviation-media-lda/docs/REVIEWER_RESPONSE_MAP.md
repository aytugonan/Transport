# Reviewer comments → code that answers them

| Comment | Requested | What this package provides |
|---|---|---|
| **R2.2** replicability and stability | estimation details; stability across initialisations | every estimator setting in `config/config.yaml`; provenance JSON (versions, config and corpus SHA-256) per step; 10 seeds × K = 15–25 with saved topic–word matrices and Hungarian matching (step 03) |
| **R2.3** source composition and uncertainty | separate composition from topic change; uncertainty | source × year counts; decomposition identity check; within-source means; LOSO (fixed-topic and refit); pooled vs source-fixed-effect slopes; document-bootstrap CIs (step 06, step 05) |
| **R2.4a** Figure 1 vs Table 3 | identical counts | both generated from the same metadata in step 01 |
| **R2.4b** keyword ranks | consistent ranking | Table 6 and Figure 3 generated from one `top_terms.csv` with weights (steps 04, 07) |
| **R2.4c** Figure 4 vs Figure 5 | consistent units | Figure 5 = counts (step 01); all proportions come from one `doc_topic.csv` (step 05) |
| **R2.4d** heatmap separators | none | `fig2_cosine_heatmap` draws no separators |
| **R2.5 / R2.7** conclusions need analytical support | tests, not caveats | `trend_slopes.csv` gives, per topic, whether the pooled CI excludes zero, whether the within-source (FE) CI excludes zero, and whether all LOSO slopes keep the sign |
| **R2.6** hydrogen/electric trajectories | dedicated evidence | Figure 6 with CIs; Table S10 with every year; Figure S2 per source |
| **R3.3** meaning of topic–word weight | explanation / useful figure | numerical β = P(w \| z) for every term (`topic_word_matrix.csv`, `top_terms.csv`) |
| **R3.4** other topic trends | all trajectories or rationale | `figureS3_all_topics` shows all 20 topics with CIs |

### Suggested wording once the real outputs exist

> Analysis code, configuration, document-level topic proportions, topic–word
> distributions, and all aggregate outputs are available at
> https://github.com/&lt;user&gt;/green-aviation-media-lda (archived at Zenodo,
> DOI 10.5281/zenodo.XXXXXXX). Full article texts are not redistributed for
> copyright reasons; the repository provides their URLs and the scripts that
> regenerate every table and figure from them.
