# Where each manuscript element comes from

All paths are relative to `outputs/` (or `outputs_demo/` for the demo).

| Manuscript element | Script | Output |
|---|---|---|
| Table 2 (selection) | — (manual screening) | document counts in `data/corpus_metadata.csv` via `retrieval_route`; arithmetic checked in `checks/` (C11) |
| Table 3 (period × country) | 01 | `tables/table3_period_country.csv` |
| Table 4 (descriptives) | 01 | `tables/table4_descriptives.csv` |
| Figure 1 (period counts) | 01 | `figures/figure1_period_counts.*` |
| Figure 5 (geography) | 01 | `figures/figure5_geography.*` |
| Table S3 | 01 | `tables/tableS3_country.csv` |
| Table S4 | 01 | `tables/tableS4_period_totals.csv` |
| Figure S1 (by year) | 01 | `figures/figureS1_year_counts.*` |
| *new* source × year counts | 01 | `tables/source_by_year.csv` |
| Section 3.2 exclusions | 01 | `preprocessing/exclusions.csv`, `preprocessing/summary.json` |
| Table 5 | 02 | `tables/table5_model_selection.csv` |
| Table S6 (10-seed grid) | 03 | `tables/tableS6_multiseed.csv`, `multiseed/runs.csv` |
| Table S7 (topic stability) | 03 | `tables/tableS7_topic_stability_K20.csv`, `multiseed/matched_cosine_K20_runs.csv` |
| Table S8 (paired bootstrap) | 03 | `tables/tableS8_paired_bootstrap.csv` |
| Table 6 (+ weights) | 04 | `tables/table6_reproduced.csv`, `final_model/top_terms.csv` |
| Topic ↔ manuscript numbering | 04 | `final_model/suggested_topic_mapping.csv` → commit to `config/topic_labels.yaml` |
| Model artefacts | 04 | `final_model/` (`doc_topic.csv`, `topic_word_matrix.csv`, `lda_model.pkl`, `pyldavis.html`, …) |
| Figure 4 (6 MA trajectories) | 05 | `figures/figure4_trajectories.*`, `temporal/moving_average_3yr.csv` |
| Figure 6 (T3/T11) | 05 | `figures/figure6_propulsion.*` |
| Table S10 | 05 | `tables/tableS10_annual_T3_T11.csv` |
| *new* all 20 topics with CIs (R3.4) | 05 | `figures/figureS3_all_topics.*`, `temporal/annual_bootstrap_ci.csv` |
| Section 3.5 decomposition identity | 06 | `source_sensitivity/decomposition_check.json` |
| Figure S2 (source-specific) | 06 | `figures/figureS2_source_specific.*`, `source_sensitivity/source_annual_means.csv` |
| *new* LOSO and source-FE trends (R2.3) | 06 | `source_sensitivity/trend_slopes.csv`, `loso_annual_means.csv`, `loso_refit_*.csv` |
| Figure 2 (cosine matrix) | 07 | `figures/figure2_cosine_similarity.*`, `similarity/cosine_matrix.csv` |
| Figure 3 (keyword overlap) | 07 | `figures/figure3_overlap_reported.*` (from Table 6), `figure3_overlap_model.*` (from fitted model) |
| Table S11 (validation checks) | 08, 09 | `checks/reported_consistency.md`, `checks/reproduced_vs_reported.md` |
| Table S12 (Figure 4 selection) | config | `figures.figure4_topics` in `config/config.yaml` |
